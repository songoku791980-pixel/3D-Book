# Interactive Pharmaceutical Textbook — Solutions

A premium immersive 3D educational textbook built with **React + TypeScript + Three.js + React Three Fiber + Drei + Framer Motion**, transforming a pharmaceutics lecture on **Solutions** (dosage forms) into an interactive digital textbook.

## Source of truth

All educational content is extracted verbatim from the uploaded PDF (`Solution 1.pdf`, 38 pages) and preserved exactly — no omissions, no simplifications, no invented facts. See `src/content/data.ts`.

## Features

- Realistic 3D hardcover book on an academic desk (curved page block near spine, stacked page edges, bookmark ribbon, warm studio lighting)
- Top-down angled camera (~55–65°) with OrbitControls
- Left page: lesson content, objectives, definitions, tables, equations, Doctor's notes
- Right page: visual explanations, interactive 3D diagrams, hotspots
- Interactive 3D scientific models: molecular dissolution, micellar solubilization, pH–solubility, complexation, particle size, oil vs aqueous depot release
- Predict-before-reveal, lift-the-flap answers, step-by-step animations, interactive hotspots, knowledge-check quizzes with immediate feedback
- Page-turning navigation, table of contents, chapter nav, progress bar, bookmarks, full-text search, fullscreen, keyboard navigation (arrows)

## Tech stack

React 18 · TypeScript · Vite · Three.js · @react-three/fiber · @react-three/drei · Framer Motion · Tailwind CSS · Lucide React

## Install & run (network required for npm)

The sandbox where this was authored had its package registry blocked, so dependencies were **not** installed here. On a machine with network access:

```bash
cd textbook
npm install
npm run dev      # dev server at http://localhost:5173
npm run build    # production build
npm run preview  # preview the production build
```

## Project layout

- `src/content/data.ts` — all PDF content, structured into 4 chapters / ~20 spreads
- `src/types.ts` — shared TypeScript types
- `src/App.tsx` — app shell, state, navigation, overlays
- `src/components/Book3D.tsx` — Three.js/R3F book environment
- `src/components/SpreadView.tsx` — left/right page editorial layout
- `src/components/ContentRenderer.tsx` — premium typography renderer
- `src/components/DiagramView.tsx` — interactive 3D diagrams
- `src/components/{PredictModal,LiftTheFlap,StepPlayer,KnowledgeCheck,HotspotPanel}.tsx` — active-learning features
- `src/components/NavBar.tsx`, `src/components/ChapterNav.tsx` — navigation & search
- `src/hooks/useIsMobile.ts` — responsive hook
- `src/index.css` — editorial design system (ivory, navy, teal, sage, gold)

## Notes

- The in-app workspace preview has no network access, so the Three.js scene won't render there. Open the app in a normal browser after `npm install` for the full 3D experience.
- Scientific equations are rendered as styled editorial callouts; LaTeX is preserved as source text in `data.ts`.
