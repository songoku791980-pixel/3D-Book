/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ivory: '#f9f7f1',
        'ivory-dark': '#f1ead4',
        navy: '#1a2e4a',
        'navy-light': '#243e66',
        teal: '#2e6e6e',
        'teal-light': '#5b9aa0',
        sage: '#8a9a7a',
        gold: '#b98a3c',
        'gold-light': '#d4a55a',
        parchment: '#efe9d9',
        ink: '#2b2b2b',
      },
      fontFamily: {
        serif: ['"Crimson Text"', 'Georgia', 'Cambria', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        display: ['"Playfair Display"', '"Crimson Text"', 'Georgia', 'serif'],
      },
      fontSize: {
        body: ['1.05rem', { lineHeight: '1.75' }],
        'body-sm': ['0.95rem', { lineHeight: '1.7' }],
        h1: ['2.75rem', { lineHeight: '1.2', letterSpacing: '-0.02em' }],
        h2: ['1.75rem', { lineHeight: '1.3', letterSpacing: '-0.01em' }],
        h3: ['1.25rem', { lineHeight: '1.4' }],
        caption: ['0.8rem', { lineHeight: '1.5' }],
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            color: theme('colors.ink'),
            maxWidth: 'none',
          },
        },
      }),
    },
  },
  plugins: [],
}
