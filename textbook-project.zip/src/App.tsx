import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { CHAPTERS, ALL_SPREADS } from './content/data';
import Book3D from './components/Book3D';
import SpreadView from './components/SpreadView';
import DiagramView from './components/DiagramView';
import PredictModal from './components/PredictModal';
import LiftTheFlap from './components/LiftTheFlap';
import StepPlayer from './components/StepPlayer';
import KnowledgeCheck from './components/KnowledgeCheck';
import HotspotPanel from './components/HotspotPanel';
import NavBar from './components/NavBar';
import ChapterNav from './components/ChapterNav';
import { useIsMobile } from './hooks/useIsMobile';

export default function App() {
  const isMobile = useIsMobile();
  const [chapterIdx, setChapterIdx] = useState(0);
  const [spreadIdx, setSpreadIdx] = useState(0);
  const [openDiagram, setOpenDiagram] = useState<string | null>(null);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);
  const [predictOpen, setPredictOpen] = useState<string | null>(null);
  const [flapOpen, setFlapOpen] = useState<string | null>(null);
  const [stepOpen, setStepOpen] = useState<string | null>(null);
  const [quizOpen, setQuizOpen] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set());

  // Reset spread when chapter changes so spreadIdx stays in range
  useEffect(() => {
    setSpreadIdx(0);
    setOpenDiagram(null);
    setPredictOpen(null);
    setFlapOpen(null);
    setStepOpen(null);
    setQuizOpen(null);
    setActiveHotspot(null);
  }, [chapterIdx]);

  const chapter = CHAPTERS[chapterIdx];
  const spread = chapter.spreads[spreadIdx];

  const isBookmarked = bookmarks.has(spread.id);
  const toggleBookmark = useCallback(() => {
    setBookmarks((prev) => {
      const next = new Set(prev);
      if (next.has(spread.id)) next.delete(spread.id);
      else next.add(spread.id);
      return next;
    });
  }, [spread.id]);

  const totalSpreads = ALL_SPREADS.length;
  const currentFlatIndex = ALL_SPREADS.findIndex((s) => s.id === spread.id);
  const progress = totalSpreads > 0 ? (currentFlatIndex + 1) / totalSpreads : 0;

  const goToSpread = useCallback((id: string) => {
    const found = ALL_SPREADS.find((s) => s.id === id);
    if (!found) return;
    setChapterIdx(CHAPTERS.findIndex((c) => c.id === found.chapterId));
    setSpreadIdx(found.spreadIndex);
    setOpenDiagram(null);
    setPredictOpen(null);
    setFlapOpen(null);
    setStepOpen(null);
    setQuizOpen(null);
  }, []);

  const nextSpread = useCallback(() => {
    const i = currentFlatIndex;
    if (i < 0 || i >= totalSpreads - 1) return;
    const nxt = ALL_SPREADS[i + 1];
    setChapterIdx(CHAPTERS.findIndex((c) => c.id === nxt.chapterId));
    setSpreadIdx(nxt.spreadIndex);
  }, [currentFlatIndex, totalSpreads]);

  const prevSpread = useCallback(() => {
    const i = currentFlatIndex;
    if (i <= 0) return;
    const prv = ALL_SPREADS[i - 1];
    setChapterIdx(CHAPTERS.findIndex((c) => c.id === prv.chapterId));
    setSpreadIdx(prv.spreadIndex);
  }, [currentFlatIndex]);

  const searchResults = useMemo(() => {
    if (!searchQuery) return [];
    const q = searchQuery.toLowerCase();
    return ALL_SPREADS.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.left.some((b) => 'text' in b && b.text.toLowerCase().includes(q)) ||
        s.right.some((b) => 'text' in b && b.text.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)
        return;
      if (e.key === 'ArrowRight' || e.key === 'PageDown') nextSpread();
      else if (e.key === 'ArrowLeft' || e.key === 'PageUp') prevSpread();
      else if (e.key === 'Escape') {
        setOpenDiagram(null);
        setPredictOpen(null);
        setFlapOpen(null);
        setStepOpen(null);
        setQuizOpen(null);
        setActiveHotspot(null);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [nextSpread, prevSpread]);

  const toggleFullscreen = useCallback(() => {
    const el = document.documentElement;
    if (!fullscreen) {
      const p = el.requestFullscreen?.();
      p?.catch(() => {});
      setFullscreen(true);
    } else {
      const p2 = document.exitFullscreen?.();
      p2?.catch(() => {});
      setFullscreen(false);
    }
  }, [fullscreen]);

  return (
    <div
      className={`text-container relative min-h-screen bg-ivory text-ink selection:bg-gold/30 selection:text-navy ${
        fullscreen ? 'h-screen overflow-hidden' : ''
      }`}
    >
      <header className="text-header">
        <div className="flex items-center justify-between px-6 py-4 md:px-8 md:py-6 z-20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded bg-navy flex items-center justify-center text-gold text-lg font-bold shadow-lg">
              S
            </div>
            <div>
              <div className="text-sm font-semibold tracking-wider text-navy uppercase letter-spacing-widest">
                Pharmaceutics
              </div>
              <div className="text-xs text-teal font-medium">Interactive 3D Textbook</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={toggleFullscreen}
              className="w-10 h-10 rounded bg-ivory-dark border border-navy/30 text-navy flex items-center justify-center text-sm transition hover:bg-gold hover:text-white"
              title="Fullscreen"
            >
              ⛶
            </button>
          </div>
        </div>
        <div className="w-full h-1 bg-ivory-dark relative overflow-hidden">
          <div
            className="h-full bg-gold origin-left transition-transform duration-500"
            style={{ transform: `scaleX(${Math.min(progress, 1)})` }}
          />
        </div>
      </header>

      <main className="relative z-10">
        <Book3D spread={spread} onDiagramSelect={setOpenDiagram} />
        <SpreadView
          spread={spread}
          chapter={chapter}
          chapterIdx={chapterIdx}
          spreadIdx={spreadIdx}
          onDiagramSelect={setOpenDiagram}
          onHotspotSelect={setActiveHotspot}
          onPrev={prevSpread}
          onNext={nextSpread}
          isBookmarked={isBookmarked}
          onToggleBookmark={toggleBookmark}
        />
        <NavBar
          chapters={CHAPTERS}
          chapterIdx={chapterIdx}
          spreadIdx={spreadIdx}
          spread={spread}
          onChapterChange={setChapterIdx}
          onGoToSpread={goToSpread}
          progress={progress}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          searchResults={searchResults}
          onCloseSearch={() => setSearchQuery('')}
          bookmarks={bookmarks}
          onToggleBookmark={toggleBookmark}
          isBookmarked={isBookmarked}
        />
        {openDiagram && (
          <DiagramView
            diagramId={openDiagram}
            spread={spread}
            onClose={() => setOpenDiagram(null)}
            onHotspotSelect={setActiveHotspot}
          />
        )}
        {spread.features?.predictBeforeReveal && predictOpen === spread.features.predictBeforeReveal.id && (
          <PredictModal
            feature={spread.features.predictBeforeReveal}
            onComplete={() => setPredictOpen(null)}
            onRunDiagram={() => {
              setPredictOpen(null);
              setOpenDiagram(spread.features!.predictBeforeReveal!.diagramKind);
            }}
          />
        )}
        {spread.features?.liftTheFlap && flapOpen === spread.features.liftTheFlap.id && (
          <LiftTheFlap
            feature={spread.features.liftTheFlap}
            onClose={() => setFlapOpen(null)}
          />
        )}
        {spread.features?.stepAnimation && stepOpen === spread.features.stepAnimation.id && (
          <StepPlayer
            steps={spread.features.stepAnimation.steps}
            title={spread.features.stepAnimation.title}
            onClose={() => setStepOpen(null)}
          />
        )}
        {spread.features?.knowledgeCheck && quizOpen === spread.features.knowledgeCheck.id && (
          <KnowledgeCheck
            questions={spread.features.knowledgeCheck.questions}
            onClose={() => setQuizOpen(null)}
          />
        )}
        {activeHotspot && spread.features?.hotspots && (
          <HotspotPanel
            hotspots={spread.features.hotspots}
            activeId={activeHotspot}
            onClose={() => setActiveHotspot(null)}
          />
        )}
      </main>

      <ChapterNav
        chapter={chapter}
        chapterIdx={chapterIdx}
        onChapterChange={(i) => {
          setChapterIdx(i);
          setSpreadIdx(0);
        }}
      />
      {isMobile && <div className="md:hidden h-16" />}
    </div>
  );
}
