export type ContentBlock =
  | { type: 'heading'; level: 1 | 2 | 3; text: string }
  | { type: 'paragraph'; text: string }
  | { type: 'list'; items: string[]; ordered?: boolean }
  | { type: 'example'; text: string }
  | { type: 'note'; text: string; label?: string }
  | { type: 'equation'; latex: string; label?: string }
  | { type: 'table'; rows: string[][]; caption?: string }
  | { type: 'advantage'; num: number; text: string }
  | { type: 'disadvantage'; num: number; text: string }
  | { type: 'image'; caption: string; kind: 'diagram' };

export interface Spread {
  id: string;
  chapterId: string;
  spreadIndex: number;
  title: string;
  left: ContentBlock[];
  right: ContentBlock[];
  diagram?: DiagramDef;
  features?: {
    predictBeforeReveal?: PredictFeature;
    liftTheFlap?: LiftTheFlapFeature;
    hotspots?: HotspotDef[];
    stepAnimation?: StepAnimationDef;
    knowledgeCheck?: KnowledgeCheckDef;
  };
  estimatedMinutes?: number;
  learningObjectives?: string[];
}

export interface DiagramDef {
  id: string;
  kind: 'molecular' | 'micelle' | 'ph' | 'complex' | 'particle' | 'oilrelease';
  title: string;
  label: string;
}

export interface PredictFeature {
  id: string;
  question: string;
  options: { id: string; text: string }[];
  correctId: string;
  explanation: string;
  incorrectExplanations: Record<string, string>;
  diagramKind: DiagramDef['kind'];
}

export interface LiftTheFlapFeature {
  id: string;
  question: string;
  answer: string;
  explanation: string;
}

export interface HotspotDef {
  id: string;
  name: string;
  position: [number, number, number];
  function: string;
  importance: string;
  relationship: string;
}

export interface StepAnimationDef {
  id: string;
  title: string;
  steps: { label: string; description: string }[];
}

export interface KnowledgeCheckDef {
  id: string;
  questions: KnowledgeQuestion[];
}

export type KnowledgeQuestion =
  | { kind: 'mcq'; id: string; question: string; options: string[]; answer: number; explanation: string }
  | { kind: 'term'; id: string; term: string; definition: string; explanation: string }
  | { kind: 'match'; id: string; prompt: string; pairs: { left: string; right: string }[]; explanation: string }
  | { kind: 'complete'; id: string; prompt: string; answer: string; explanation: string }
  | { kind: 'short'; id: string; question: string; answer: string; explanation: string };

export interface Chapter {
  id: string;
  title: string;
  subtitle: string;
  learningObjectives?: string[];
  spreads: Spread[];
}
