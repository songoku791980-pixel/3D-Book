export type ContentBlock =
  | { type: 'heading'; level: 1 | 2 | 3; text: string }
  | { type: 'paragraph'; text: string }
  | { type: 'list'; items: string[]; ordered?: boolean }
  | { type: 'example'; text: string }
  | { type: 'note'; text: string; label?: string }
  | { type: 'equation'; latex: string; label?: string }
  | { type: 'table'; rows: string[][]; caption?: string }
  | { type: 'advantage'; num: number; text: string }
  | { type: 'disadvantage'; num: number; text: string }
  | { type: 'image'; caption: string; kind: 'diagram' };

export interface Spread {
  id: string;
  chapterId: string;
  spreadIndex: number;
  title: string;
  left: ContentBlock[];
  right: ContentBlock[];
  diagram?: DiagramDef;
  features?: {
    predictBeforeReveal?: PredictFeature;
    liftTheFlap?: LiftTheFlapFeature;
    hotspots?: HotspotDef[];
    stepAnimation?: StepAnimationDef;
    knowledgeCheck?: KnowledgeCheckDef;
  };
  estimatedMinutes?: number;
  learningObjectives?: string[];
}

export interface DiagramDef {
  id: string;
  kind: 'molecular' | 'micelle' | 'ph' | 'complex' | 'particle' | 'oilrelease';
  title: string;
  label: string;
}

export interface PredictFeature {
  id: string;
  question: string;
  options: { id: string; text: string }[];
  correctId: string;
  explanation: string;
  incorrectExplanations: Record<string, string>;
  diagramKind: DiagramDef['kind'];
}

export interface LiftTheFlapFeature {
  id: string;
  question: string;
  answer: string;
  explanation: string;
}

export interface HotspotDef {
  id: string;
  name: string;
  position: [number, number, number];
  function: string;
  importance: string;
  relationship: string;
}

export interface StepAnimationDef {
  id: string;
  title: string;
  steps: { label: string; description: string }[];
}

export interface KnowledgeCheckDef {
  id: string;
  questions: KnowledgeQuestion[];
}

export type KnowledgeQuestion =
  | { kind: 'mcq'; id: string; question: string; options: string[]; answer: number; explanation: string }
  | { kind: 'term'; id: string; term: string; definition: string; explanation: string }
  | { kind: 'match'; id: string; prompt: string; pairs: { left: string; right: string }[]; explanation: string }
  | { kind: 'complete'; id: string; prompt: string; answer: string; explanation: string }
  | { kind: 'short'; id: string; question: string; answer: string; explanation: string };

/* ============================================================================
   CHAPTER 1 — INTRODUCTION TO SOLUTIONS  (PDF pp. 1–7)
   ============================================================================ */

export const CHAPTER_1_SPREADS: Spread[] = [
  {
    id: 'ch1-spread-1',
    chapterId: 'ch1',
    spreadIndex: 0,
    title: 'Introduction to Solutions',
    estimatedMinutes: 8,
    learningObjectives: [
      'Define a solution as a homogeneous one-phase system.',
      'Distinguish between solvent and solute.',
      'Recognize that the solvent is usually present in the greater amount.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'Definition' },
      {
        type: 'paragraph',
        text: 'A solution is a homogeneous one-phase system consisting of two or more components.',
      },
      { type: 'heading', level: 3, text: 'Solvent and Solute' },
      {
        type: 'paragraph',
        text: 'The solvent is that phase in which the dispersion occurs, and the solute is that component which is dispersed as small molecules or ions in the solvent.',
      },
      { type: 'note', text: 'In general the solvent is present in the greater amount, but there are several exceptions.', label: 'Important' },
      { type: 'example', text: 'Syrup BP contains 66.7% w/w of sucrose as the solute in 33.3% w/w of water as the solvent.' },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Dissolution at the Molecular Level' },
      { type: 'paragraph', text: 'Solute particles disperse evenly throughout the solvent to form a single, uniform phase.' },
    ],
    diagram: {
      id: 'diag-dissolution',
      kind: 'molecular',
      title: 'Molecular Dissolution',
      label: 'Solute ⇌ Solvent interaction',
    },
    features: {
      predictBeforeReveal: {
        id: 'pred-dissolution',
        question: 'When a solute is added to a solvent and dissolves completely, what is the resulting system called?',
        options: [
          { id: 'a', text: 'A suspension' },
          { id: 'b', text: 'A homogeneous one-phase solution' },
          { id: 'c', text: 'An emulsion' },
          { id: 'd', text: 'A two-phase mixture' },
        ],
        correctId: 'b',
        explanation: 'A solution is defined as a homogeneous one-phase system consisting of two or more components.',
        incorrectExplanations: {
          a: 'A suspension is a heterogeneous two-phase system in which solid particles are dispersed in a liquid but do not dissolve.',
          c: 'An emulsion consists of two immiscible liquids, one dispersed in the other — it is not a true solution.',
          d: 'A solution is a single phase, not two phases.',
        },
        diagramKind: 'molecular',
      },
    },
  },
  {
    id: 'ch1-spread-2',
    chapterId: 'ch1',
    spreadIndex: 1,
    title: 'Advantages of Solutions as an Oral Dosage Form',
    estimatedMinutes: 10,
    learningObjectives: [
      'List the advantages of liquid oral solutions over solid dosage forms.',
      'Explain why solutions offer faster therapeutic response.',
      'Understand uniformity of dose and reduced gastric irritation.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'Advantages of Solutions' },
      { type: 'paragraph', text: 'Solutions offer several advantages as an oral dosage form:' },
      { type: 'advantage', num: 1, text: 'Liquids are easier to swallow than solids and are therefore particularly acceptable for pediatric and geriatric use.' },
      { type: 'advantage', num: 2, text: 'A drug must be in solution before it can be absorbed. A drug administered in the form of a solution is immediately available for absorption.' },
      { type: 'paragraph', text: 'Thus the therapeutic response is faster than if using a solid dosage form which must first disintegrate in order to allow the drug to dissolve in the gastrointestinal fluid before absorption can begin.' },
      { type: 'advantage', num: 3, text: 'A solution is a homogeneous system and therefore the drug will be uniformly distributed throughout the preparation. In suspension or emulsion formulations uneven dosage can occur due to phase separation on storage.' },
      { type: 'advantage', num: 4, text: 'Some drugs, including aspirin and potassium chloride, can irritate and damage the gastric mucosa particularly if localized in one area as often occurs after the ingestion of a solid dosage form. Irritation is reduced by administration of a solution of a drug because of the immediate dilution by the gastric contents.' },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Solid vs. Solution Absorption' },
      { type: 'paragraph', text: 'Compare how a solid dosage form must disintegrate and dissolve, while a solution is immediately available for absorption.' },
    ],
    diagram: {
      id: 'diag-absorption',
      kind: 'molecular',
      title: 'Absorption Pathway',
      label: 'Solution → immediate absorption vs. Solid → disintegrate → dissolve → absorb',
    },
  },
  {
    id: 'ch1-spread-3',
    chapterId: 'ch1',
    spreadIndex: 2,
    title: 'Disadvantages of Solutions',
    estimatedMinutes: 10,
    learningObjectives: [
      'List the disadvantages of liquid solutions.',
      'Explain stability, microbial growth, and dosage-accuracy concerns.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'Disadvantages of Solutions' },
      { type: 'paragraph', text: 'Solutions also present several disadvantages:' },
      { type: 'disadvantage', num: 1, text: 'Liquids are bulky and therefore inconvenient to transport and store.' },
      { type: 'disadvantage', num: 2, text: 'Provide suitable media for the growth of microorganisms and may therefore require the incorporation of a preservative.' },
      { type: 'disadvantage', num: 3, text: 'The stability of ingredients in aqueous solution is often poorer than if they were formulated as a tablet or capsule, particularly if they are susceptible to hydrolysis.' },
      { type: 'disadvantage', num: 4, text: 'The shelf life of a liquid dosage form is therefore often much shorter than the corresponding solid preparation.' },
      { type: 'disadvantage', num: 5, text: 'Not only is the stability of the drug of importance but also that of other excipients such as surfactants, preservatives, flavours and colours.' },
      { type: 'disadvantage', num: 6, text: 'Accurate dosage usually depends on the ability of the patient to use a 5 ml spoon or more rarely, a volumetric dropper.' },
      { type: 'disadvantage', num: 7, text: 'The taste of a drug, which is usually unpleasant, is always more pronounced when in solution than when in a solid form. Solutions can, however, easily be sweetened and flavoured to make them more palatable.' },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Solution Stability Considerations' },
      { type: 'paragraph', text: 'Key factors affecting solution stability over storage time.' },
    ],
    diagram: {
      id: 'diag-stability',
      kind: 'molecular',
      title: 'Stability Factors',
      label: 'Hydrolysis · Microbial growth · Precipitation',
    },
    features: {
      liftTheFlap: {
        id: 'flap-taste',
        question: 'Why is the taste of a drug usually more pronounced in solution than in solid form?',
        answer: 'Because the drug is already dissolved and in contact with the taste buds, so its flavour is immediately perceived.',
        explanation: 'In a solid form the drug must first dissolve in saliva before its taste is detected. In solution, the dissolved drug contacts the taste buds at once, making unpleasant tastes more pronounced. Solutions can, however, be sweetened and flavoured to improve palatability.',
      },
    },
  },
];

/* ============================================================================
   CHAPTER 2 — AQUEOUS SOLUTIONS  (PDF pp. 8–12)
   ============================================================================ */

export const CHAPTER_2_SPREADS: Spread[] = [
  {
    id: 'ch2-spread-1',
    chapterId: 'ch2',
    spreadIndex: 0,
    title: 'Water as a Pharmaceutical Solvent',
    estimatedMinutes: 8,
    learningObjectives: [
      'State why water is the most widely used pharmaceutical solvent.',
      'List the properties that make water suitable as a vehicle.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'Formulation of Solutions — Aqueous Solutions' },
      {
        type: 'paragraph',
        text: 'Water is the most widely used solvent for use as a vehicle for pharmaceutical products because of:',
      },
      { type: 'list', items: ['lack of toxicity', 'physiological compatibility', 'ability to dissolve a wide range of materials'], ordered: false },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Water Molecule & Solvation' },
    ],
    diagram: {
      id: 'diag-water',
      kind: 'molecular',
      title: 'The Water Molecule',
      label: 'Polar solvent · hydrogen bonding · solvation shell',
    },
  },
  {
    id: 'ch2-spread-2',
    chapterId: 'ch2',
    spreadIndex: 1,
    title: 'Types of Water',
    estimatedMinutes: 8,
    learningObjectives: [
      'Distinguish potable water, purified water BP, and water for injections BP.',
      'State how each type is prepared and its intended use.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'Three Types of Water' },
      {
        type: 'list',
        items: [
          'Potable water: can be used; freshly drawn from the mains system and suitable for drinking.',
          'Purified water BP: freshly boiled and cooled before use to destroy any microorganisms which may be present. Purified water BP should be used where the presence of salts in potable water is undesirable. Purified water BP is normally prepared by the distillation or deionization of potable water.',
          'Water for injections BP: used for the formulation of parenteral solutions and is obtained by the sterilization of pyrogen-free distilled water immediately after collection.',
        ],
        ordered: true,
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Water Grades Comparison' },
      { type: 'table', rows: [
        ['Type', 'Preparation', 'Use'],
        ['Potable water', 'Drawn from mains; suitable for drinking', 'General use where salts are acceptable'],
        ['Purified water BP', 'Boiled and cooled; distilled or deionized', 'Where salts in potable water are undesirable'],
        ['Water for injections BP', 'Sterilization of pyrogen-free distilled water', 'Parenteral solutions'],
      ], caption: 'Comparison of the three grades of water used in pharmaceutics.' },
    ],
    diagram: {
      id: 'diag-watertypes',
      kind: 'molecular',
      title: 'Water Grades',
      label: 'Potable · Purified BP · WFI',
    },
  },
  {
    id: 'ch2-spread-3',
    chapterId: 'ch2',
    spreadIndex: 2,
    title: 'Special Water Requirements for Sensitive Drugs',
    estimatedMinutes: 8,
    learningObjectives: [
      'Identify drugs sensitive to carbon dioxide and oxidation.',
      'Explain how CO₂-free and air-free water for injections BP is prepared.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'For the formulation of aqueous solutions of drugs, such as phenobarbitone sodium or aminophylline, which are sensitive to the presence of carbon dioxide, or drugs which are liable to oxidation, such as apomorphine and ergotamine maleate, then water for injections BP free from carbon dioxide or free from air must be used.',
      },
      {
        type: 'paragraph',
        text: 'These are both obtained from apyrogenic distilled water in the same way as before, but are then boiled for at least 10 minutes, cooled, sealed in their containers whilst excluding air and then sterilized by autoclaving.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Sensitive Drugs & Water Treatment' },
      { type: 'table', rows: [
        ['Drug', 'Sensitivity', 'Water Requirement'],
        ['Phenobarbitone sodium, aminophylline', 'Carbon dioxide', 'WFI free from carbon dioxide'],
        ['Apomorphine, ergotamine maleate', 'Oxidation (air)', 'WFI free from air'],
      ], caption: 'Processing steps: boil ≥10 min → cool → seal excluding air → autoclave.' },
    ],
    diagram: {
      id: 'diag-sensitive',
      kind: 'molecular',
      title: 'Oxidation / CO₂ Sensitivity',
      label: 'Boil 10 min · seal · autoclave',
    },
  },
  {
    id: 'ch2-spread-4',
    chapterId: 'ch2',
    spreadIndex: 3,
    title: 'Solubility Limits and Precipitation',
    estimatedMinutes: 8,
    learningObjectives: [
      'Explain why complete solution may not be possible at all storage temperatures.',
      'Describe the risk of precipitation on cooling or evaporation.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'Although water is very widely used for inclusion in pharmaceutical preparations, it may not be possible to ensure complete solution of all ingredients at all normal storage temperatures.',
      },
      {
        type: 'paragraph',
        text: 'It is important to ensure that the concentration of any material is not close to its limit of solubility as precipitation may occur if the product is cooled or if any evaporation of the vehicle occurs.',
      },
      {
        type: 'paragraph',
        text: 'In these cases one or more of the following methods may be used in order to improve aqueous solubility.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Precipitation Risk' },
      { type: 'note', text: 'Keep concentration well below the limit of solubility to avoid precipitation on cooling or evaporation.', label: 'Principle' },
      { type: 'paragraph', text: 'Six approaches to improve aqueous solubility follow in Chapter 3.' },
    ],
    diagram: {
      id: 'diag-precipitation',
      kind: 'particle',
      title: 'Precipitation on Cooling',
      label: 'Supersaturated → crystals form on cooling',
    },
  },
];

/* ============================================================================
   CHAPTER 3 — IMPROVING AQUEOUS SOLUBILITY  (PDF pp. 13–26)
   ============================================================================ */

export const CHAPTER_3_SPREADS: Spread[] = [
  {
    id: 'ch3-spread-0',
    chapterId: 'ch3',
    spreadIndex: 0,
    title: 'Six Approaches to Improve Aqueous Solubility',
    estimatedMinutes: 6,
    learningObjectives: [
      'List the six approaches used to improve aqueous solubility.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'Approaches to the Improvement of Aqueous Solubility' },
      { type: 'list', items: [
        '1- Co-solvency',
        '2- pH control',
        '3- Solubilization',
        '4- Complexation',
        '5- Chemical modification',
        '6- Particle size control',
      ], ordered: true },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Overview of Approaches' },
      { type: 'paragraph', text: 'Each approach is detailed in the following spreads.' },
    ],
    diagram: {
      id: 'diag-overview',
      kind: 'molecular',
      title: 'Solubility-Enhancement Approaches',
      label: 'Co-solvency · pH · Solubilization · Complexation · Chemical modification · Particle size',
    },
  },
  {
    id: 'ch3-spread-1',
    chapterId: 'ch3',
    spreadIndex: 1,
    title: '1 · Co-solvency',
    estimatedMinutes: 10,
    learningObjectives: [
      'Explain how a water-miscible co-solvent improves solubility.',
      'Identify suitable pharmaceutical co-solvents and examples.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'The solubility of a weak electrolyte or non-polar compound in water can often be improved by the addition of a water-miscible solvent in which the compound is also soluble. Vehicles used in combination to increase the solubility of a drug are called co-solvents, and often the solubility in this mixed system is greater than can be predicted from the material\'s solubility in each individual solvent.',
      },
      {
        type: 'paragraph',
        text: 'The choice of suitable co-solvents is somewhat limited for pharmaceutical use because of possible toxicity and irritancy, particularly if required for oral or parenteral use. The most widely used system is a water/ethanol blend; other suitable solvents including sorbitol, glycerol and propylene glycol.',
      },
      { type: 'example', text: 'A blend of propylene glycol and water is used to improve the solubility of co-trimoxazole.' },
      { type: 'example', text: 'Paracetamol is formulated as an elixir by the use of alcohol, propylene glycol and syrup.' },
      { type: 'example', text: 'For external application to the scalp, betamethasone valerate is available dissolved in a water/isopropyl alcohol mixture.' },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Co-solvent System' },
      { type: 'table', rows: [
        ['Co-solvent system', 'Example application'],
        ['Water / ethanol', 'Paracetamol elixir'],
        ['Propylene glycol / water', 'Co-trimoxazole'],
        ['Water / isopropyl alcohol', 'Betamethasone valerate (scalp)'],
      ], caption: 'Common co-solvent blends and their uses.' },
    ],
    diagram: {
      id: 'diag-cosolvency',
      kind: 'molecular',
      title: 'Co-solvency',
      label: 'Water-miscible co-solvent increases drug solubility',
    },
    features: {
      predictBeforeReveal: {
        id: 'pred-cosolvency',
        question: 'Why is the solubility in a co-solvent mixture often greater than predicted from each solvent alone?',
        options: [
          { id: 'a', text: 'Because the two solvents react chemically with the drug' },
          { id: 'b', text: 'Because the mixed solvent system solvates the drug more effectively than either solvent individually' },
          { id: 'c', text: 'Because co-solvents always increase temperature' },
          { id: 'd', text: 'Because co-solvents precipitate the drug' },
        ],
        correctId: 'b',
        explanation: 'Co-solvents are vehicles used in combination; the solubility in the mixed system is often greater than can be predicted from the material\'s solubility in each individual solvent.',
        incorrectExplanations: {
          a: 'Co-solvents do not react chemically with the drug.',
          c: 'Co-solvents do not inherently increase temperature.',
          d: 'Co-solvents improve, not reduce, solubility.',
        },
        diagramKind: 'molecular',
      },
    },
  },
  {
    id: 'ch3-spread-2',
    chapterId: 'ch3',
    spreadIndex: 2,
    title: '2 · pH Control',
    estimatedMinutes: 8,
    learningObjectives: [
      'State how pH affects the solubility of weak acids and weak bases.',
      'Explain why pH must be controlled in parenteral and ophthalmic solutions.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'If a drug is either a weak acid or a weak base, then its solubility in water can be influenced by the pH of the system. The solubility of a weak base can be increased by lowering the pH of its solution, whereas the solubility of a weak acid is improved by a pH increase.',
      },
      {
        type: 'paragraph',
        text: 'The pH of solutions for parenteral and ophthalmic use, for application to mucous membranes or for use on abraded skin must also be controlled as extremes can cause pain and irritation. This is particularly true for subcutaneous, intramuscular and C.N.S. injections because the solutions will not be rapidly diluted after administration.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: pH and Solubility' },
      { type: 'table', rows: [
        ['Drug type', 'Action to increase solubility'],
        ['Weak base', 'Lower the pH'],
        ['Weak acid', 'Increase the pH'],
      ], caption: 'pH manipulation to improve solubility of weak electrolytes.' },
    ],
    diagram: {
      id: 'diag-ph',
      kind: 'ph',
      title: 'pH–Solubility Relationship',
      label: 'Weak base: ↓pH → ↑solubility · Weak acid: ↑pH → ↑solubility',
    },
  },
  {
    id: 'ch3-spread-3',
    chapterId: 'ch3',
    spreadIndex: 3,
    title: '3 · Solubilization (Micellar Solubilization)',
    estimatedMinutes: 12,
    learningObjectives: [
      'Explain how surface active agents improve solubility via micelles.',
      'State the role of HLB and the risks of too much/too little SAA.',
      'List the characteristics of a suitable solubilizing agent.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'The solubility of a drug which is normally insoluble or poorly soluble in water can often be improved by the addition of a surface active agent (SAA). This phenomenon of micellar solubilization has been widely used for the formulation of solutions. The amount of SAA must be carefully controlled.',
      },
      { type: 'note', text: 'A large excess is undesirable because of cost, possible toxic effects, and may reduce the bioavailability of a drug due to its strong adsorption within the micelle.', label: 'Caution' },
      { type: 'note', text: 'An insufficient amount of surfactant may not solubilize all of the drug or may lead to precipitation on storage or on dilution of the product.', label: 'Caution' },
      {
        type: 'paragraph',
        text: 'Hydrophilic SAA possessing HLB values above 15 will be of particular value as solubilizing agents.',
      },
      { type: 'heading', level: 3, text: 'Characteristics of SAA' },
      { type: 'list', items: [
        'Nontoxic and nonirritant, bearing in mind its intended route of administration.',
        'Miscible with the solvent system.',
        'Compatible with the other ingredients.',
        'Free from disagreeable odour and taste and be non-volatile.',
      ], ordered: false },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Micelle Formation' },
      { type: 'table', rows: [
        ['SAA amount', 'Effect'],
        ['Large excess', 'Cost, toxicity, reduced bioavailability (adsorption in micelle)'],
        ['Insufficient', 'Incomplete solubilization or precipitation on storage/dilution'],
        ['HLB > 15 (hydrophilic)', 'Valuable as solubilizing agents'],
      ], caption: 'Micellar solubilization — balancing surfactant concentration.' },
    ],
    diagram: {
      id: 'diag-micelle',
      kind: 'micelle',
      title: 'Micellar Solubilization',
      label: 'Hydrophobic core · hydrophilic shell · drug solubilized in core',
    },
    features: {
      hotspots: [
        { id: 'hs-core', name: 'Hydrophobic core', position: [0, 0, 0], function: 'Houses poorly soluble drug molecules', importance: 'Enables dissolution of water-insoluble drugs', relationship: 'Surrounded by the hydrophilic shell' },
        { id: 'hs-shell', name: 'Hydrophilic shell', position: [0, 0, 1.2], function: 'Faces the aqueous medium', importance: 'Keeps the micelle dispersed in water', relationship: 'Encapsulates the hydrophobic core' },
        { id: 'hs-drug', name: 'Solubilized drug', position: [-0.6, 0, 0], function: 'The poorly soluble drug', importance: 'Carried into aqueous solution', relationship: 'Resides within the hydrophobic core' },
      ],
      stepAnimation: {
        id: 'steps-micelle',
        title: 'How Micellar Solubilization Works',
        steps: [
          { label: 'SAA added to water', description: 'Surface active agents orient at the water interface.' },
          { label: 'Micelle forms', description: 'SAA molecules assemble with hydrophobic tails inward, hydrophilic heads outward.' },
          { label: 'Drug enters core', description: 'Poorly soluble drug partitions into the hydrophobic core.' },
          { label: 'Solubilized', description: 'The drug is now carried in aqueous solution.' },
        ],
      },
    },
  },
  {
    id: 'ch3-spread-4',
    chapterId: 'ch3',
    spreadIndex: 4,
    title: '4 · Complexation',
    estimatedMinutes: 8,
    learningObjectives: [
      'Define complexation and its role in solubility.',
      'Explain why complex formation must be reversible.',
      'Give the iodine–polyvinyl pyrrolidone example.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'Interaction of a poorly soluble drug with a soluble material to form a soluble intermolecular complex. As most complexes are macromolecular, however, they tend to be inactive, being unable to cross lipid membranes. It is essential, therefore, that complex formation is easily reversible so that the free drug is released during or before contact with biological fluids.',
      },
      { type: 'example', text: 'The complexation of iodine with a 10–15% solution of polyvinyl pyrrolidone to improve the aqueous solubility of the active agent.' },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Drug–Host Complex' },
      { type: 'note', text: 'The complex must release free drug before contact with biological fluids so it can cross lipid membranes.', label: 'Key principle' },
    ],
    diagram: {
      id: 'diag-complex',
      kind: 'complex',
      title: 'Drug–Host Complexation',
      label: 'Reversible · soluble complex · free drug released',
    },
  },
  {
    id: 'ch3-spread-5',
    chapterId: 'ch3',
    spreadIndex: 5,
    title: '5 · Chemical Modification',
    estimatedMinutes: 10,
    learningObjectives: [
      'Explain chemical modification to create water-soluble derivatives.',
      'List examples of salt formation.',
      'Understand the regulatory implications (new chemical entities).',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'Chemical modification of a drug may be necessary in order to produce a water-soluble derivative.',
      },
      { type: 'example', text: 'The synthesis of the sodium phosphate salts of hydrocortisone, prednisolone and betamethasone.' },
      { type: 'example', text: 'The water-soluble chloramphenicol sodium succinate has no antibacterial activity of its own but is suitable for parenteral administration as a solution in order to obtain high blood levels, after which it is converted back to the active base.' },
      {
        type: 'paragraph',
        text: 'Although many poorly soluble drugs have been modified in this way, they are, of course, regarded as new chemical entities and thus full toxicity, pharmacology and preformulation studies may be required for these as well as for their parent compounds.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Salt Formation' },
      { type: 'table', rows: [
        ['Parent drug', 'Water-soluble derivative'],
        ['Hydrocortisone', 'Sodium phosphate salt'],
        ['Prednisolone', 'Sodium phosphate salt'],
        ['Betamethasone', 'Sodium phosphate salt'],
        ['Chloramphenicol', 'Sodium succinate (water-soluble, inactive until converted back)'],
      ], caption: 'Examples of chemical modification to improve aqueous solubility.' },
    ],
    diagram: {
      id: 'diag-chemmod',
      kind: 'molecular',
      title: 'Chemical Modification',
      label: 'Drug → water-soluble salt → active base regenerated',
    },
  },
  {
    id: 'ch3-spread-6',
    chapterId: 'ch3',
    spreadIndex: 6,
    title: '6 · Particle Size Control',
    estimatedMinutes: 6,
    learningObjectives: [
      'State the effect of particle size on solubility.',
      'Identify the size threshold (<1 µm).',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'The size and shape of very small particles, if less than 1 µm diameter, can affect their solubility. As particle size decreases, solubility will increase.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Surface Area & Solubility' },
      { type: 'note', text: 'Smaller particles → larger surface-area-to-volume ratio → increased solubility (for particles < 1 µm).', label: 'Principle' },
    ],
    diagram: {
      id: 'diag-particle',
      kind: 'particle',
      title: 'Particle Size Effect',
      label: '↓ particle size → ↑ surface area → ↑ solubility',
    },
  },
];

/* ============================================================================
   CHAPTER 4 — NON-AQUEOUS SOLUTIONS  (PDF pp. 27–37)
   ============================================================================ */

export const CHAPTER_4_SPREADS: Spread[] = [
  {
    id: 'ch4-spread-0',
    chapterId: 'ch4',
    spreadIndex: 0,
    title: 'Non-Aqueous Solutions — Overview',
    estimatedMinutes: 8,
    learningObjectives: [
      'State when non-aqueous solvents are used.',
      'Understand depot therapy with oily intramuscular injections.',
    ],
    left: [
      { type: 'heading', level: 2, text: 'B — Non-Aqueous Solutions: The Use of Alternative Solvents' },
      { type: 'list', items: [
        'If it is not possible to ensure complete solution of the ingredients at all storage temperatures.',
        'If the drug is unstable in aqueous systems.',
      ], ordered: true },
      { type: 'note', text: 'The intramuscular injection of solutions of drugs in oils is often used for depot therapy.', label: 'N.B.' },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Oil vs Aqueous Release' },
      { type: 'paragraph', text: 'Oily solutions release drug slowly into surrounding tissue; aqueous solutions diffuse rapidly.' },
    ],
    diagram: {
      id: 'diag-oilrelease',
      kind: 'oilrelease',
      title: 'Depot Release (Oil vs Aqueous)',
      label: 'Oil: slow release · Aqueous: rapid diffusion',
    },
  },
  {
    id: 'ch4-spread-1',
    chapterId: 'ch4',
    spreadIndex: 1,
    title: 'Oil Solubility & Depot Therapy',
    estimatedMinutes: 8,
    learningObjectives: [
      'Explain how esterification improves oil solubility.',
      'Compare oil-based vs aqueous-based release.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'Some drugs are specifically synthesized to improve their oil solubilities — the propionate and benzoate esters of testosterone and oestradiol, respectively.',
      },
      {
        type: 'paragraph',
        text: 'The oily solution is releasing the drug slowly into the surrounding tissue whereas a similar aqueous solution would diffuse rapidly and, being miscible with tissue fluid, would cause the drug to be released quickly.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Esterified Drug Release' },
      { type: 'table', rows: [
        ['Drug', 'Oil-soluble ester'],
        ['Testosterone', 'Propionate / benzoate esters'],
        ['Oestradiol', 'Benzoate ester'],
      ], caption: 'Esterification improves oil solubility for depot (slow) release.' },
    ],
    diagram: {
      id: 'diag-oilrelease',
      kind: 'oilrelease',
      title: 'Oil vs Aqueous Depot Release',
      label: 'Slow oily release vs rapid aqueous diffusion',
    },
  },
  {
    id: 'ch4-spread-2',
    chapterId: 'ch4',
    spreadIndex: 2,
    title: 'Selecting a Non-Aqueous Solvent',
    estimatedMinutes: 8,
    learningObjectives: [
      'List criteria for choosing a non-aqueous solvent.',
      'Understand solvent choice constraints by route of administration.',
    ],
    left: [
      {
        type: 'paragraph',
        text: 'For choosing a suitable solvent, its toxicity, irritancy and sensitizing potential must be taken into account as well as its flammability, cost, stability and compatibility with other excipients.',
      },
      {
        type: 'paragraph',
        text: 'There is a greater choice of solvent available for inclusion into products for external application than those for internal use, while for parenteral products the choice is even further limited.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Solvent Choice by Route' },
      { type: 'table', rows: [
        ['Route', 'Solvent choice'],
        ['External application', 'Greater choice'],
        ['Internal use', 'More limited'],
        ['Parenteral', 'Most limited'],
      ], caption: 'Constraints on solvent selection by route of administration.' },
    ],
    diagram: {
      id: 'diag-route',
      kind: 'molecular',
      title: 'Solvent Choice by Route',
      label: 'External > Internal > Parenteral (increasing restriction)',
    },
  },
  {
    id: 'ch4-spread-3',
    chapterId: 'ch4',
    spreadIndex: 3,
    title: 'Classification of Non-Aqueous Solvents (1–3)',
    estimatedMinutes: 12,
    learningObjectives: [
      'Classify non-aqueous solvents into fixed oils, alcohols, and polyhydric alcohols.',
      'Give examples and uses of each class.',
    ],
    left: [
      { type: 'heading', level: 3, text: '1. Fixed Oils of Vegetable Origin' },
      {
        type: 'paragraph',
        text: 'These are non-volatile oils which consist mainly of fatty acid esters of glycerol. Almond oil — solvent for oily phenol injection BP for treating haemorrhoids. Arachis oil — solvent in Dimercaprol injection BP. Castor oil — solvent in physostigmine oily eye drops BP and formulations of triamcinolone ear drops.',
      },
      {
        type: 'paragraph',
        text: 'Olive oil, sesame oil, maize oil, cottonseed oil, soya oil and castor oil are all suitable for parenteral use. Some fixed oils are sufficiently tasteless and odourless to be suitable for oral use as solvents for such materials as vitamins A and D.',
      },
      { type: 'heading', level: 3, text: '2. Alcohols' },
      {
        type: 'paragraph',
        text: 'Ethyl alcohol is the most widely used solvent in this class, particularly for external application, where its rapid evaporation after application to the skin imparts a cooling effect to such products as salicylic acid lotion BP. At concentrations greater than 15% it exhibits antimicrobial activity but because of its toxicity it is used orally or parenterally only at low concentrations, usually as a co-solvent with water.',
      },
      { type: 'heading', level: 3, text: '3. Polyhydric Alcohols' },
      {
        type: 'paragraph',
        text: 'Alcohols containing two hydroxyl groups per molecule are known as glycols but due to their toxicity are rarely used internally. One important exception is propylene glycol (CH₃CH(OH)CH₂OH). Propylene glycol is often used in conjunction with water or glycerol as a co-solvent. Propylene glycol is used, for example, in the formulation of Digoxin injection BP, phenobarbitone injection BP, some formulations of Diazepam injection BP, and in many preparations for oral use.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Solvent Classes 1–3' },
      { type: 'table', rows: [
        ['Class', 'Examples', 'Typical use'],
        ['Fixed oils', 'Almond, arachis, castor, olive, sesame', 'Oily injections, eye/ear drops, oral vitamin solvents'],
        ['Alcohols', 'Ethyl alcohol', 'External lotions; low-conc. co-solvent'],
        ['Polyhydric alcohols', 'Propylene glycol, glycerol, PEG 400', 'Co-solvents, injections, oral preparations'],
      ], caption: 'Non-aqueous solvent classes and representative examples.' },
    ],
    diagram: {
      id: 'diag-solvents1',
      kind: 'molecular',
      title: 'Solvent Classes 1–3',
      label: 'Fixed oils · Alcohols · Polyhydric alcohols',
    },
  },
  {
    id: 'ch4-spread-4',
    chapterId: 'ch4',
    spreadIndex: 4,
    title: 'Classification of Non-Aqueous Solvents (4–7)',
    estimatedMinutes: 10,
    learningObjectives: [
      'Identify DMSO, ethyl ether, liquid paraffin, and miscellaneous solvents.',
      'State uses and cautions for each.',
    ],
    left: [
      { type: 'heading', level: 3, text: '4. Dimethyl sulphoxide (DMSO)' },
      {
        type: 'paragraph',
        text: 'This is a highly polar compound and is thought to aid the penetration of drugs through the skin. It is used as a carrier for idoxuridine, an antiviral agent for application to human skin.',
      },
      { type: 'heading', level: 3, text: '5. Ethyl ether' },
      {
        type: 'paragraph',
        text: 'This material is widely used for the extraction of crude drugs but because of its own therapeutic activity is not used for the preparation of formulations for internal use. It is, however, used as a co-solvent with alcohol.',
      },
      { type: 'heading', level: 3, text: '6. Liquid paraffin' },
      {
        type: 'paragraph',
        text: 'The oily nature of this material makes it unpleasant to use externally, although it is often used as a solvent for the topical application of drugs in emulsion formulations. At one time light liquid paraffin was widely used as the base for oily nasal drops which are now rarely used because of the possibility of causing lipoidal pneumonia if inhaled into the lungs.',
      },
      { type: 'heading', level: 3, text: '7. Miscellaneous solvents' },
      {
        type: 'paragraph',
        text: 'Isopropyl myristate and isopropyl palmitate are oily materials used as solvents for external use particularly in cosmetics where their low viscosity and lack of greasiness make them pleasant to use.',
      },
    ],
    right: [
      { type: 'heading', level: 2, text: 'Visual: Solvent Classes 4–7' },
      { type: 'table', rows: [
        ['Solvent', 'Key property / use', 'Caution'],
        ['DMSO', 'Aids skin penetration; carrier for idoxuridine', 'Highly polar'],
        ['Ethyl ether', 'Extraction of crude drugs; co-solvent with alcohol', 'Not for internal use'],
        ['Liquid paraffin', 'Topical emulsions; formerly nasal drops', 'Lipoidal pneumonia risk if inhaled'],
        ['Isopropyl myristate / palmitate', 'Cosmetic solvents; low viscosity, non-greasy', 'External use only'],
      ], caption: 'Remaining non-aqueous solvent classes.' },
    ],
    diagram: {
      id: 'diag-solvents2',
      kind: 'molecular',
      title: 'Solvent Classes 4–7',
      label: 'DMSO · Ethyl ether · Liquid paraffin · Miscellaneous',
    },
    features: {
      knowledgeCheck: {
        id: 'kc-ch4',
        questions: [
          { kind: 'mcq', id: 'q1', question: 'Which of the following is used for depot therapy by intramuscular injection in an oily solution?', options: ['Water', 'Fixed oils of vegetable origin', 'Ethyl ether', 'Liquid paraffin for internal use'], answer: 1, explanation: 'The intramuscular injection of solutions of drugs in oils is often used for depot therapy.' },
          { kind: 'mcq', id: 'q2', question: 'Propylene glycol is an example of which class of non-aqueous solvent?', options: ['Fixed oil', 'Alcohol (monohydric)', 'Polyhydric alcohol', 'Miscellaneous solvent'], answer: 2, explanation: 'Propylene glycol (CH₃CH(OH)CH₂OH) contains two hydroxyl groups and is a polyhydric alcohol/glycol.' },
          { kind: 'term', id: 'q3', term: 'Depot therapy', definition: 'The intramuscular injection of solutions of drugs in oils, releasing the drug slowly into surrounding tissue.', explanation: 'Oily solutions release drug slowly; aqueous solutions diffuse rapidly.' },
          { kind: 'complete', id: 'q4', prompt: 'Fixed oils of vegetable origin consist mainly of __________.', answer: 'fatty acid esters of glycerol', explanation: 'Fixed oils are non-volatile oils consisting mainly of fatty acid esters of glycerol.' },
        ],
      },
    },
  },
];

/* ============================================================================
   ALL CHAPTERS
   ============================================================================ */

export interface Chapter {
  id: string;
  title: string;
  subtitle: string;
  spreads: Spread[];
}

export const CHAPTERS: Chapter[] = [
  {
    id: 'ch1',
    title: 'Introduction to Solutions',
    subtitle: 'Definition, components, advantages & disadvantages',
    spreads: CHAPTER_1_SPREADS,
  },
  {
    id: 'ch2',
    title: 'Aqueous Solutions',
    subtitle: 'Water types and special requirements',
    spreads: CHAPTER_2_SPREADS,
  },
  {
    id: 'ch3',
    title: 'Improving Aqueous Solubility',
    subtitle: 'Co-solvency, pH, solubilization, complexation, chemical modification, particle size',
    spreads: CHAPTER_3_SPREADS,
  },
  {
    id: 'ch4',
    title: 'Non-Aqueous Solutions',
    subtitle: 'Alternative solvents, depot therapy, solvent classification',
    spreads: CHAPTER_4_SPREADS,
  },
];

/* Flattened list of all spreads for navigation / progress / search */
export const ALL_SPREADS: Spread[] = CHAPTERS.flatMap((c) =>
  c.spreads.map((s) => ({ ...s, chapterId: c.id }))
);

export const CHAPTER_TITLES: Record<string, string> = Object.fromEntries(
  CHAPTERS.map((c) => [c.id, c.title])
);