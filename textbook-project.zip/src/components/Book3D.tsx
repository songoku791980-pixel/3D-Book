import React from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import type { Spread } from '@/types';

interface Book3DProps {
  spread: Spread;
  onDiagramSelect: (kind: string) => void;
}

const NAVY = 0x1a2e4a;
const GOLD = 0xb98a3c;
const IVORY = 0xf9f7f1;

export default function Book3D({ spread, onDiagramSelect }: Book3DProps) {
  useFrame((state) => {
    const elapsed = state.clock.getElapsedTime();
    state.camera.position.z = 5.8 + Math.sin(elapsed * 0.5) * 0.03;
    state.camera.position.y = 4.8 + Math.sin(elapsed * 0.7) * 0.02;
    state.camera.lookAt(0, 0.4, 0);
  });

  const handleClick = (event: any) => {
    if (event?.intersects?.[0]?.object?.userData?.diagramKind) {
      onDiagramSelect(event.intersects[0].object.userData.diagramKind);
    }
  };

  return (
    <Canvas
      shadows
      camera={{ position: [0, 4.8, 5.8], fov: 45, near: 0.1, far: 100 }}
      gl={{ antialias: true, alpha: true }}
      style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'auto' }}
    >
      <OrbitControls
        enableZoom={true}
        enableRotate={true}
        enablePan={false}
        minDistance={3.5}
        maxDistance={10}
        minPolarAngle={Math.PI / 3.2}
        maxPolarAngle={Math.PI / 2.1}
        autoRotate={false}
        enableDamping
      />
      <ambientLight intensity={0.5} color={0xffffff} />
      <hemisphereLight
        position={[0, 1, 0]}
        color={0xf9f7f1}
        groundColor={0x2b2b2b}
        intensity={0.35}
      />
      <directionalLight
        position={[-3, 6, 3]}
        intensity={0.85}
        color={0xfff5e1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <pointLight position={[3, 4, -2]} intensity={0.25} color={0xffe8d1} />
      <spotLight
        position={[0, 5, 4]}
        intensity={0.45}
        color={0xfff5e1}
        penumbra={0.8}
        castShadow
        distance={14}
        angle={Math.PI / 4}
        decay={1.5}
      />

      {/* Desk surface */}
      <mesh receiveShadow>
        <planeGeometry args={[16, 16]} />
        <meshStandardMaterial color={0xe8e0d0} roughness={0.8} metalness={0.05} />
      </mesh>
      {/* Desk front edge */}
      <mesh receiveShadow position={[0, -0.06, 3.5]}>
        <boxGeometry args={[16, 0.12, 1.4]} />
        <meshStandardMaterial color={0xc9bda3} roughness={0.9} />
      </mesh>

      {/* Book group */}
      <group
        position={[0, 0.02, 0]}
        rotation={[-0.02, 0, 0]}
        onClick={handleClick}
      >
        {/* Left hardcover board */}
        <mesh castShadow receiveShadow position={[-1.34, 0, 0]} rotation={[0, 0, -0.04]}>
          <boxGeometry args={[2.7, 0.15, 2.0]} />
          <meshStandardMaterial
            color={NAVY}
            roughness={0.75}
            metalness={0.25}
            envMapIntensity={0.6}
          />
        </mesh>
        {/* Right hardcover board */}
        <mesh castShadow receiveShadow position={[1.34, 0, 0]} rotation={[0, 0, 0.04]}>
          <boxGeometry args={[2.7, 0.15, 2.0]} />
          <meshStandardMaterial
            color={NAVY}
            roughness={0.75}
            metalness={0.25}
            envMapIntensity={0.6}
          />
        </mesh>
        {/* Spine */}
        <mesh castShadow receiveShadow position={[0, 0, 1.03]}>
          <boxGeometry args={[0.07, 0.17, 2.2]} />
          <meshStandardMaterial color={0x142238} roughness={0.8} metalness={0.15} />
        </mesh>
        {/* Page block (curved toward spine) - half cylinder arc */}
        <mesh castShadow receiveShadow position={[0, -0.03, 0]}>
          <cylinderGeometry args={[1.04, 1.04, 0.06, 80, 1, true, 0, Math.PI]} />
          <meshStandardMaterial
            color={IVORY}
            roughness={0.85}
            metalness={0}
            side={THREE.DoubleSide}
          />
        </mesh>
        {/* Front face of curved page block */}
        <mesh castShadow receiveShadow position={[0, -0.03, -1.02]}>
          <cylinderGeometry args={[1.04, 1.04, 0.05, 80, 1, true, 0, Math.PI]} />
          <meshStandardMaterial color={0xf1ead4} roughness={0.9} side={THREE.DoubleSide} />
        </mesh>
        {/* Outer page edges (right stack) */}
        <mesh castShadow receiveShadow position={[1.06, -0.03, 0]} rotation={[0, 0, Math.PI / 2]}>
          <boxGeometry args={[0.05, 2.08, 0.06]} />
          <meshStandardMaterial color={0xefe9d9} roughness={0.9} metalness={0} />
        </mesh>
        {/* Inner page edges near spine */}
        <mesh castShadow receiveShadow position={[0, -0.03, 1.03]}>
          <boxGeometry args={[2.14, 0.05, 0.05]} />
          <meshStandardMaterial color={0xf1ead4} roughness={0.9} />
        </mesh>
        {/* Bookmark ribbon */}
        <mesh position={[0, 0.125, 0]}>
          <boxGeometry args={[0.075, 0.032, 1.7]} />
          <meshStandardMaterial color={0x7a1f2b} roughness={0.6} metalness={0.1} />
        </mesh>
        <mesh position={[0, 0.125, -0.8]}>
          <boxGeometry args={[0.075, 0.032, 0.65]} />
          <meshStandardMaterial color={0x5a1520} roughness={0.6} metalness={0.1} />
        </mesh>

        {/* Right-page diagram activator target */}
        <mesh
          userData={{ diagramKind: spread.diagram?.kind || 'molecular' }}
          position={[1.02, -0.02, 0]}
          rotation={[0, 0, Math.PI / 2]}
        >
          <planeGeometry args={[1.75, 1.55]} />
          <meshStandardMaterial color={0xffffff} transparent opacity={0} />
        </mesh>

        {/* Gold cover accent lines */}
        <mesh position={[-1.3, 0, 0.03]} rotation={[0, 0, -0.04]}>
          <boxGeometry args={[2.62, 0.015, 0.02]} />
          <meshStandardMaterial color={GOLD} roughness={0.3} metalness={0.9} />
        </mesh>
        <mesh position={[1.3, 0, 0.03]} rotation={[0, 0, 0.04]}>
          <boxGeometry args={[2.62, 0.015, 0.02]} />
          <meshStandardMaterial color={GOLD} roughness={0.3} metalness={0.9} />
        </mesh>
      </group>
    </Canvas>
  );
}
