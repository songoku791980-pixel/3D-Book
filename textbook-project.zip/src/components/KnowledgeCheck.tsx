import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import type { KnowledgeQuestion } from '@/types';

interface KnowledgeCheckProps {
  questions: KnowledgeQuestion[];
  onClose: () => void;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function KnowledgeCheck({ questions, onClose }: KnowledgeCheckProps) {
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [submitted, setSubmitted] = useState<Set<string>>(new Set());
  const [score, setScore] = useState(0);

  const qList = shuffle(questions);

  const isAnswered = (id: string) => submitted.has(id);

  const handleSubmit = (id: string, value: any) => {
    setAnswers((prev) => ({ ...prev, [id]: value }));
    setSubmitted((prev) => new Set([...prev, id]));

    const q = qList.find((x) => x.id === id)!;
    let correct = false;
    if (q.kind === 'mcq') correct = value === q.answer;
    else if (q.kind === 'complete') correct = String(value).trim().toLowerCase() === q.answer.trim().toLowerCase();
    else if (q.kind === 'short') correct = String(value).trim().length > 0; // subjective; mark as answered
    else if (q.kind === 'term') correct = String(value).trim().length > 0;
    else if (q.kind === 'match') {
      correct = JSON.stringify(value) === JSON.stringify(q.pairs.map((p) => p.right));
    }
    if (correct) setScore((s) => s + 1);
  };

  const reset = () => {
    setAnswers({});
    setSubmitted(new Set());
    setScore(0);
  };

  const renderQuestion = (q: KnowledgeQuestion) => {
    const answered = isAnswered(q.id);
    const value = answers[q.id];

    switch (q.kind) {
      case 'mcq':
        return (
          <div className="space-y-3" key={q.id}>
            {q.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleSubmit(q.id, i)}
                disabled={answered}
                className={`w-full text-left py-3 px-4 rounded-lg border text-sm font-serif text-left transition-all ${
                  answered
                    ? i === q.answer
                      ? 'border-gold bg-gold/10 text-navy'
                      : i === value
                        ? 'border-red/30 bg-red/5 text-red/90'
                        : 'border-navy/20 text-ink/60 bg-ivory/50'
                    : 'border-navy/30 text-ink hover:bg-ivory-dark'
                }`}
              >
                {opt}
              </button>
            ))}
            {answered && (
              <div className="flex items-start gap-2 pt-2">
                {value === q.answer ? (
                  <span className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-700 shrink-0" />
                    <span className="text-sm text-green-800 font-serif">Correct — {q.explanation}</span>
                  </span>
                ) : (
                  <span className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-red-700 shrink-0" />
                    <span className="text-sm text-red-800 font-serif">
                      Incorrect. {q.explanation}
                    </span>
                  </span>
                )}
              </div>
            )}
          </div>
        );
      case 'term':
        return (
          <div className="space-y-3" key={q.id}>
            <div className="bg-ivory-dark p-4 rounded-xl border border-navy/20">
              <div className="text-xs font-semibold text-navy uppercase tracking-wider mb-2">Term:</div>
              <div className="text-lg font-serif font-bold text-navy">{q.term}</div>
            </div>
            {!answered && (
              <textarea
                value={value ?? ''}
                onChange={(e) => handleSubmit(q.id, e.target.value)}
                className="w-full mt-3 p-3 rounded-lg border border-navy/30 bg-white text-sm font-serif focus:outline-none focus:border-gold"
                rows={3}
                placeholder="Write the definition..."
                disabled={answered}
              />
            )}
            {answered && (
              <div className="pt-2">
                <div className="text-xs font-semibold text-navy uppercase tracking-wider mb-1">Your answer:</div>
                <p className="text-sm text-ink/80 font-serif italic">{value}</p>
                <div className="flex items-start gap-2 mt-2">
                  <span className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-700 shrink-0" />
                    <span className="text-sm text-green-800 font-serif">
                      Definition: {q.definition}. {q.explanation}
                    </span>
                  </span>
                </div>
              </div>
            )}
          </div>
        );
      case 'complete':
        return (
          <div className="space-y-3" key={q.id}>
            <div className="text-ink/80 leading-relaxed font-serif text-sm">{q.prompt}</div>
            {!answered && (
              <input
                value={value ?? ''}
                onChange={(e) => handleSubmit(q.id, e.target.value)}
                className="w-full p-3 rounded-lg border border-navy/30 bg-white text-sm font-serif focus:outline-none focus:border-gold"
                placeholder="Complete the following..."
                disabled={answered}
              />
            )}
            {answered && (
              <div className="pt-2 flex items-start gap-2">
                {String(value).trim().toLowerCase() === q.answer.trim().toLowerCase() ? (
                  <span className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-700 shrink-0" />
                    <span className="text-sm text-green-800 font-serif">Correct — {q.explanation}</span>
                  </span>
                ) : (
                  <span className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-red-700 shrink-0" />
                    <span className="text-sm text-red-800 font-serif">
                      Incorrect. Correct answer: "{q.answer}". {q.explanation}
                    </span>
                  </span>
                )}
              </div>
            )}
          </div>
        );
      case 'match':
        return (
          <div className="space-y-3" key={q.id}>
            <div className="text-ink/80 leading-relaxed font-serif text-sm">{q.prompt}</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {q.pairs.map((p, i) => (
                <div key={i} className="flex items-center gap-2 p-3 bg-ivory-dark rounded-lg border border-navy/20">
                  <span className="text-sm text-navy font-serif">{p.left}</span>
                  <span className="text-xs text-ink/50">→</span>
                  <span className="ml-2 text-sm text-ink/80 font-serif italic">
                    {answered ? value?.[i] : '(select match)'}
                  </span>
                </div>
              ))}
            </div>
            {!answered && (
              <div className="pt-3">
                <p className="text-xs text-ink/50 mb-2">Tap each item to reveal its correct match.</p>
                <button
                  onClick={() => handleSubmit(q.id, q.pairs.map((p) => p.right))}
                  className="text-xs text-navy underline"
                >
                  Reveal matches
                </button>
              </div>
            )}
            {answered && (
              <div className="pt-2 flex items-start gap-2">
                <span className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-700 shrink-0" />
                  <span className="text-sm text-green-800 font-serif">{q.explanation}</span>
                </span>
              </div>
            )}
          </div>
        );
      case 'short':
        return (
          <div className="space-y-3" key={q.id}>
            <div className="text-ink/80 leading-relaxed font-serif text-sm">{q.question}</div>
            {!answered && (
              <textarea
                value={value ?? ''}
                onChange={(e) => handleSubmit(q.id, e.target.value)}
                className="w-full p-3 rounded-lg border border-navy/30 bg-white text-sm font-serif focus:outline-none focus:border-gold"
                rows={4}
                placeholder="Type your answer..."
                disabled={answered}
              />
            )}
            {answered && (
              <div className="pt-2 border-l-2 border-gold bg-gold/5 p-3">
                <div className="text-xs font-semibold text-navy uppercase tracking-wider mb-1">Guideline answer:</div>
                <p className="text-sm text-ink/80 font-serif italic">{q.answer}</p>
                <p className="text-xs text-ink/60 mt-1">{q.explanation}</p>
              </div>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  const answeredCount = submitted.size;
  const finished = answeredCount === qList.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 pointer-events-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="pointer-events-auto relative w-full max-w-2xl bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
      >
        <div className="bg-navy p-5 flex items-center justify-between">
          <h2 className="text-lg font-serif font-bold text-white">Knowledge check</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
          >
            <X />
          </button>
        </div>

        <div className="p-6 md:p-8">
          {!finished ? (
            <div className="flex-1 overflow-y-auto pr-2">
              <div className="text-xs text-ink/50 mb-3 flex justify-between">
                <span>{answeredCount} / {qList.length} answered</span>
                <span className="font-semibold text-navy">Score: {score}</span>
              </div>
              {qList.map((q) => (
                <motion.div
                  key={q.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-6"
                >
                  {renderQuestion(q)}
                </motion.div>
              ))}
              <div className="mt-8 flex justify-end">
                <button
                  onClick={reset}
                  className="text-sm text-navy hover:text-teal mr-4"
                >
                  <RefreshCw className="w-4 h-4 mr-1" /> Reset
                </button>
                <button
                  onClick={onClose}
                  className="text-sm font-semibold text-navy hover:text-teal"
                >
                  Close &amp; return
                </button>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-10">
              <div className="w-20 h-20 rounded-full bg-gold/10 flex items-center justify-center text-6xl text-gold mb-4">
                {score >= qList.length * 0.7 ? '✓' : '★'}
              </div>
              <h3 className="text-2xl font-serif font-bold text-navy mb-2">
                Lesson complete
              </h3>
              <p className="text-lg text-ink/70 font-serif mb-6">
                You scored {score} out of {qList.length}.
              </p>
              {score >= qList.length * 0.7 ? (
                <p className="text-sm text-green-700 font-serif">Strong understanding — you're ready to move on.</p>
              ) : (
                <p className="text-sm text-red-700 font-serif">Review the lesson content and try again.</p>
              )}
              <div className="mt-8 flex gap-3">
                <button onClick={reset} className="px-5 py-2 rounded-lg border border-navy text-navy font-medium hover:bg-gold hover:text-white transition">
                  Retry
                </button>
                <button onClick={onClose} className="px-5 py-2 rounded-lg bg-navy text-white font-medium hover:bg-teal transition">
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
