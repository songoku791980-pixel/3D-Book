import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { X } from 'lucide-react';
import type { Spread } from '@/types';

interface DiagramViewProps {
  diagramId: string;
  spread: Spread;
  onClose: () => void;
  onHotspotSelect: (id: string) => void;
}

const NAVY = 0x1a2e4a;
const GOLD = 0xb98a3c;
const TEAL = 0x2e6e6e;
const SAGE = 0x8a9a7a;
const IVORY = 0xf9f7f1;
const RED = 0x9b2226;

function material(color: number, opts: any = {}) {
  return (
    <meshStandardMaterial color={color} roughness={0.6} metalness={0.1} {...opts} />
  );
}

// ---------------- 1. Molecular dissolution ----------------
function MolecularDiagram({ onHotspotSelect }: any) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!ref.current) return;
    ref.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    ref.current.children.forEach((child: any, i: number) => {
      if (child.userData.solvent) {
        child.position.y = Math.sin(t * 1.5 + i) * 0.05;
        child.rotation.z += 0.01;
      }
    });
  });

  return (
    <group ref={ref} userData={{ kind: 'molecular' }} onClick={onHotspotSelect}>
      <pointLight position={[0, 3, 4]} intensity={0.6} color={0xfff5e1} />
      <ambientLight intensity={0.4} />
      {[...Array(24)].map((_, i) => (
        <mesh
          key={i}
          userData={{ solvent: true, id: `solvent-${i}` }}
          position={[Math.sin(i) * 1.4, Math.cos(i) * 1.4, (i % 3 - 1) * 0.6]}
          scale={0.35}
          onClick={(e) => {
            e.stopPropagation();
            onHotspotSelect(`solvent-${i}`);
          }}
        >
          <sphereGeometry args={[1, 16, 16]} />
          {material(TEAL, { transparent: true, opacity: 0.55 })}
        </mesh>
      ))}
      <mesh
        userData={{ kind: 'solute', id: 'solute-core' }}
        position={[0, 0, 0]}
        scale={0.9}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('solute-core'); }}
      >
        <boxGeometry args={[0.7, 0.7, 0.7]} />
        {material(GOLD)}
      </mesh>
      {[...Array(12)].map((_, i) => (
        <mesh
          key={i}
          userData={{ kind: 'ion', id: `ion-${i}` }}
          position={[Math.sin(i) * 0.9, Math.cos(i) * 0.9, (i % 4 - 1.5) * 0.5]}
          scale={0.25}
          onClick={(e) => { e.stopPropagation(); onHotspotSelect(`ion-${i}`); }}
        >
          <octahedronGeometry args={[1, 0]} />
          {material(GOLD, { transparent: true, opacity: 0.8 })}
        </mesh>
      ))}
    </group>
  );
}

// ---------------- 2. Micelle ----------------
function MicelleDiagram({ onHotspotSelect }: any) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!ref.current) return;
    ref.current.rotation.y = Math.sin(t * 0.25) * 0.2;
    ref.current.rotation.x = Math.cos(t * 0.15) * 0.1;
  });

  return (
    <group ref={ref} userData={{ kind: 'micelle' }} onClick={onHotspotSelect}>
      <pointLight position={[0, 3, 4]} intensity={0.6} color={0xfff5e1} />
      <ambientLight intensity={0.4} />
      {[...Array(20)].map((_, i) => (
        <mesh
          key={i}
          userData={{ part: 'shell', id: `shell-${i}` }}
          position={[Math.sin(i) * 1.0, Math.cos(i) * 1.0, (i % 3 - 1) * 0.5]}
          scale={0.28}
          onClick={(e) => { e.stopPropagation(); onHotspotSelect('shell'); }}
        >
          <sphereGeometry args={[1, 14, 14]} />
          {material(TEAL)}
        </mesh>
      ))}
      <mesh
        userData={{ part: 'core', id: 'core' }}
        position={[0, 0, 0]}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('core'); }}
      >
        <icosahedronGeometry args={[0.9, 1]} />
        {material(GOLD)}
      </mesh>
      <mesh
        userData={{ part: 'drug', id: 'drug' }}
        position={[0.25, 0.25, 0.1]}
        scale={0.45}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('drug'); }}
      >
        <sphereGeometry args={[1, 12, 12]} />
        {material(NAVY)}
      </mesh>
    </group>
  );
}

// ---------------- 3. pH control ----------------
function PhDiagram({ onHotspotSelect }: any) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!ref.current) return;
    ref.current.rotation.y = Math.sin(t * 0.2) * 0.18;
    ref.current.children.forEach((child: any) => {
      if (child.userData.proton) {
        child.position.y += 0.02;
        if (child.position.y > 1.6) child.position.y = -1.6;
      }
    });
  });

  return (
    <group ref={ref} userData={{ kind: 'ph' }} onClick={onHotspotSelect}>
      <pointLight position={[0, 3, 4]} intensity={0.6} color={0xfff5e1} />
      <ambientLight intensity={0.4} />
      <mesh
        userData={{ id: 'base' }}
        position={[-0.8, 0, 0]}
        scale={0.9}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('base'); }}
      >
        <boxGeometry args={[1, 1, 1]} />
        {material(SAGE)}
      </mesh>
      {[...Array(8)].map((_, i) => (
        <mesh
          key={i}
          userData={{ proton: true, id: `hplus-${i}` }}
          position={[-0.8 + (i % 3) * 0.4, -1.4 + (i % 2) * 0.6, (Math.floor(i / 3) - 1) * 0.4]}
          scale={0.2}
          onClick={(e) => { e.stopPropagation(); onHotspotSelect(`hplus-${i}`); }}
        >
          <sphereGeometry args={[1, 10, 10]} />
          {material(RED)}
        </mesh>
      ))}
      <mesh
        userData={{ id: 'acid' }}
        position={[0.8, 0, 0]}
        scale={0.9}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('acid'); }}
      >
        <boxGeometry args={[1, 1, 1]} />
        {material(NAVY)}
      </mesh>
    </group>
  );
}

// ---------------- 4. Complexation ----------------
function ComplexDiagram({ onHotspotSelect }: any) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!ref.current) return;
    ref.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });

  return (
    <group ref={ref} userData={{ kind: 'complex' }} onClick={onHotspotSelect}>
      <pointLight position={[0, 3, 4]} intensity={0.6} color={0xfff5e1} />
      <ambientLight intensity={0.4} />
      <mesh
        userData={{ part: 'host', id: 'host' }}
        position={[-0.5, 0, 0]}
        scale={0.8}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('host'); }}
      >
        <torusGeometry args={[0.7, 0.12, 8, 24]} />
        {material(TEAL)}
      </mesh>
      <mesh
        userData={{ part: 'drug', id: 'drug' }}
        position={[0, 0, 0]}
        scale={0.5}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('drug'); }}
      >
        <sphereGeometry args={[1, 14, 14]} />
        {material(GOLD)}
      </mesh>
      <mesh
        userData={{ part: 'free', id: 'free' }}
        position={[1.6, 0, 0]}
        scale={0.55}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('free'); }}
      >
        <octahedronGeometry args={[1, 0]} />
        {material(NAVY, { transparent: true, opacity: 0.85 })}
      </mesh>
    </group>
  );
}

// ---------------- 5. Particle size ----------------
function ParticleDiagram({ onHotspotSelect }: any) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!ref.current) return;
    ref.current.rotation.y = Math.sin(t * 0.25) * 0.2;
  });

  return (
    <group ref={ref} userData={{ kind: 'particle' }} onClick={onHotspotSelect}>
      <pointLight position={[0, 3, 4]} intensity={0.6} color={0xfff5e1} />
      <ambientLight intensity={0.4} />
      <group position={[-1.4, 0, 0]}>
        <mesh userData={{ kind: 'large' }} onClick={(e) => { e.stopPropagation(); onHotspotSelect('large'); }}>
          <boxGeometry args={[0.9, 0.9, 0.9]} />
          {material(GOLD)}
        </mesh>
      </group>
      <group position={[1.4, 0, 0]}>
        {[...Array(14)].map((_, i) => (
          <mesh
            key={i}
            userData={{ kind: 'small', id: `p-${i}` }}
            position={[(i % 4) * 0.35 - 0.5, Math.floor(i / 4) * 0.35 - 0.5, 0]}
            scale={0.22}
            onClick={(e) => { e.stopPropagation(); onHotspotSelect(`p-${i}`); }}
          >
            <boxGeometry args={[1, 1, 1]} />
            {material(SAGE)}
          </mesh>
        ))}
      </group>
    </group>
  );
}

// ---------------- 6. Oil vs aqueous release ----------------
function OilReleaseDiagram({ onHotspotSelect }: any) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!ref.current) return;
    ref.current.rotation.y = Math.sin(t * 0.2) * 0.18;
    ref.current.children.forEach((child: any) => {
      if (child.userData.oil) {
        child.position.y = Math.sin(t * 0.8 + child.position.x) * 0.04;
      }
    });
  });

  return (
    <group ref={ref} userData={{ kind: 'oilrelease' }} onClick={onHotspotSelect}>
      <pointLight position={[0, 3, 4]} intensity={0.6} color={0xfff5e1} />
      <ambientLight intensity={0.4} />
      <mesh
        userData={{ kind: 'oil', id: 'oil' }}
        position={[-1.5, 0, 0]}
        scale={0.9}
        onClick={(e) => { e.stopPropagation(); onHotspotSelect('oil'); }}
      >
        <sphereGeometry args={[1, 20, 20]} />
        {material(0xd97706)}
      </mesh>
      {[...Array(10)].map((_, i) => (
        <mesh
          key={i}
          userData={{ oil: true, id: `or-${i}` }}
          position={[-1.5 + Math.sin(i) * 0.5, (i % 3) * 0.3 - 0.3, 0]}
          scale={0.18}
          onClick={(e) => { e.stopPropagation(); onHotspotSelect(`or-${i}`); }}
        >
          <sphereGeometry args={[1, 10, 10]} />
          {material(GOLD, { transparent: true, opacity: 0.7 })}
        </mesh>
      ))}
      <group position={[1.5, 0, 0]}>
        <mesh userData={{ kind: 'aq' }} onClick={(e) => { e.stopPropagation(); onHotspotSelect('aq'); }}>
          <sphereGeometry args={[0.7, 16, 16]} />
          {material(TEAL, { transparent: true, opacity: 0.6 })}
        </mesh>
        {[...Array(16)].map((_, i) => (
          <mesh
            key={i}
            userData={{ kind: 'aqp', id: `aq-${i}` }}
            position={[1.5 + Math.cos(i) * 1.2, Math.sin(i) * 1.2, (i % 3 - 1) * 0.5]}
            scale={0.15}
            onClick={(e) => { e.stopPropagation(); onHotspotSelect(`aq-${i}`); }}
          >
            <octahedronGeometry args={[1, 0]} />
            {material(TEAL)}
          </mesh>
        ))}
      </group>
    </group>
  );
}

const DIAGRAMS: Record<string, React.ComponentType<any>> = {
  molecular: MolecularDiagram,
  micelle: MicelleDiagram,
  ph: PhDiagram,
  complex: ComplexDiagram,
  particle: ParticleDiagram,
  oilrelease: OilReleaseDiagram,
};

export default function DiagramView({ diagramId, spread, onClose, onHotspotSelect }: DiagramViewProps) {
  const Kind = DIAGRAMS[diagramId] || MolecularDiagram;
  const diagram = spread.diagram || { title: '3D Diagram', label: '' };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 pointer-events-none bg-black/20 backdrop-blur-sm">
      <div className="pointer-events-auto relative w-full max-w-[700px] h-[620px] bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col">
        <div className="bg-navy p-4 flex items-center justify-between">
          <h2 className="text-base font-serif font-bold text-white">
            Interactive 3D — {diagram.title}
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
          >
            <X />
          </button>
        </div>

        <div className="flex-1 relative">
          <Canvas
            shadows
            camera={{ position: [0, 0, 5], fov: 45 }}
            gl={{ antialias: true, alpha: true }}
            style={{ width: '100%', height: '100%' }}
          >
            <ambientLight intensity={0.4} />
            <directionalLight position={[3, 5, 4]} intensity={0.8} color={0xfff5e1} castShadow />
            <Kind onHotspotSelect={onHotspotSelect} />
          </Canvas>
        </div>

        <div className="p-4 bg-ivory-dark border-t border-navy/20">
          <p className="text-[0.8rem] text-ink/70 font-serif italic text-center">
            {diagram.label}
          </p>
          <div className="flex justify-center mt-3">
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-lg bg-navy text-white font-medium text-sm hover:bg-teal transition"
            >
              Close diagram
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
