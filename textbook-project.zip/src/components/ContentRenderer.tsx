import React from 'react';
import type { ContentBlock } from '@/types';

function escapeRegExpChars(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

interface ContentRendererProps {
  blocks: ContentBlock[];
  className?: string;
}

export default function ContentRenderer({ blocks, className }: ContentRendererProps) {
  return (
    <div className={['prose-content', className].filter(Boolean).join(' ')}>
      {blocks.map((block, i) => {
        switch (block.type) {
          case 'heading': {
            const Tag = block.level === 1 ? 'h1' : block.level === 2 ? 'h2' : 'h3';
            return (
              <Tag key={i} className="editorial-heading">
                {block.text}
              </Tag>
            );
          }
          case 'paragraph':
            return <p key={i} className="editorial-paragraph">{block.text}</p>;
          case 'list':
            return (
              <ul key={i} className={`editorial-list ${block.ordered ? 'list-decimal' : 'list-disc'} pl-6 space-y-1`}>
                {block.items.map((item, j) => (
                  <li key={j} className="editorial-list-item">
                    {item}
                  </li>
                ))}
              </ul>
            );
          case 'example':
            return (
              <div key={i} className="editorial-example">
                <span className="example-label">Example.</span> {block.text}
              </div>
            );
          case 'note': {
            const label = block.label || 'Note';
            return (
              <div key={i} className="editorial-note">
                <div className="note-label">{label}</div>
                <div className="note-text">{block.text}</div>
              </div>
            );
          }
          case 'equation':
            return (
              <div key={i} className="editorial-equation">
                {block.label && <span className="eq-label">{block.label}</span>}
                <div className="eq-body" style={{ fontFamily: '"Crimson Text", serif', fontStyle: 'italic' }}>
                  {block.latex}
                </div>
              </div>
            );
          case 'table': {
            return (
              <div key={i} className="editorial-table-wrapper">
                {block.caption && <div className="table-caption">{block.caption}</div>}
                <table className="editorial-table">
                  <thead>
                    {block.rows[0] && (
                      <tr>
                        {block.rows[0].map((cell, j) => (
                          <th key={j} className="table-cell table-header">
                            {cell}
                          </th>
                        ))}
                      </tr>
                    )}
                  </thead>
                  <tbody>
                    {block.rows.slice(1).map((row, r) => (
                      <tr key={r} className="table-row">
                        {row.map((cell, j) => (
                          <td key={j} className="table-cell">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          }
          case 'advantage':
            return (
              <div key={i} className="editorial-advantage">
                <span className="advantage-num">{block.num}</span>
                <span className="advantage-text">{block.text}</span>
              </div>
            );
          case 'disadvantage':
            return (
              <div key={i} className="editorial-disadvantage">
                <span className="disadvantage-num">{block.num}</span>
                <span className="disadvantage-text">{block.text}</span>
              </div>
            );
          case 'image':
            return (
              <div key={i} className="editorial-image-caption">
                {block.caption}
              </div>
            );
          default:
            return null;
        }
      })}
    </div>
  );
}
