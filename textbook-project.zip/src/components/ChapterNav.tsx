import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Scroll } from 'lucide-react';
import type { Chapter } from '@/types';

interface ChapterNavProps {
  chapter: Chapter;
  chapterIdx: number;
  onChapterChange: (i: number) => void;
}

export default function ChapterNav({ chapter, chapterIdx, onChapterChange }: ChapterNavProps) {
  const totalChapters = 4;
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-20 pointer-events-none">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="pointer-events-auto flex justify-center items-center gap-1 px-4 py-2 md:py-3 bg-white/60 backdrop-filter backdrop-blur-md border-t border-navy/10"
      >
        {Array.from({ length: totalChapters }).map((_, i) => {
          const active = i === chapterIdx;
          return (
            <button
              key={i}
              onClick={() => onChapterChange(i)}
              className={`px-5 py-2.5 md:py-3 rounded-2xl text-xs md:text-sm font-serif transition-all ${
                active
                  ? 'bg-navy text-white shadow-lg'
                  : 'bg-ivory-dark/60 text-navy/70 border border-navy/20 hover:bg-gold hover:text-navy hover:font-semibold'
              }`}
            >
              {active ? <BookOpen className="w-3.5 h-3.5 mr-1.5" /> : <Scroll className="w-3.5 h-3.5 mr-1.5" />}
              Ch {i + 1}
            </button>
          );
        })}
      </motion.div>
    </nav>
  );
}
