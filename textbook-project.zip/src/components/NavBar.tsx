import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, List, ChevronDown, X } from 'lucide-react';
import type { Chapter, Spread } from '@/types';
import { ALL_SPREADS } from '@/content/data';

interface NavBarProps {
  chapters: Chapter[];
  chapterIdx: number;
  spreadIdx: number;
  spread: Spread;
  onChapterChange: (i: number) => void;
  onGoToSpread: (id: string) => void;
  progress: number;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  searchResults: Spread[];
  onCloseSearch: () => void;
  bookmarks: Set<string>;
  onToggleBookmark: (id: string) => void;
  isBookmarked: boolean;
}

export default function NavBar({
  chapters,
  chapterIdx,
  spreadIdx,
  spread,
  onChapterChange,
  onGoToSpread,
  progress,
  searchQuery,
  setSearchQuery,
  searchResults,
  onCloseSearch,
  bookmarks,
  onToggleBookmark,
  isBookmarked,
}: NavBarProps) {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null!);

  useEffect(() => {
    if (searchOpen && inputRef.current) inputRef.current.focus();
  }, [searchOpen]);

  const chapterSpreadCount = chapters[chapterIdx].spreads.length;
  const withinChapterProgress = chapterSpreadCount > 0 ? (spreadIdx + 1) / chapterSpreadCount : 0;

  const toggleSearch = () => setSearchOpen((o) => !o);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/70 backdrop-filter backdrop-blur-md border-t border-navy/10">
      <div className="max-w-6xl mx-auto px-6 py-3 md:px-8 md:py-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[0.7rem] font-semibold text-navy uppercase tracking-widest">Progress</span>
              <span className="ml-auto text-[0.7rem] text-ink/60 font-mono">
                {Math.round(progress * 100)}%
              </span>
            </div>
            <div className="h-1.5 bg-ivory-dark rounded overflow-hidden">
              <div className="h-full bg-gold rounded" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <div className="flex justify-between text-[0.65rem] text-ink/50 mt-1">
              <span>{chapterIdx + 1} of {chapters.length} chapters</span>
              <span>Spread {spreadIdx + 1} of {chapterSpreadCount}</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setOpen(true)}
              className="w-10 h-10 rounded bg-ivory-dark border border-navy/30 text-navy flex items-center justify-center text-sm hover:bg-gold hover:text-white transition"
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={toggleSearch}
              className="w-10 h-10 rounded bg-ivory-dark border border-navy/30 text-navy flex items-center justify-center text-sm hover:bg-gold hover:text-white transition"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={() => onToggleBookmark(spread.id)}
              className={`w-10 h-10 rounded flex items-center justify-center text-navy transition all ${
                isBookmarked ? 'bg-gold text-white' : 'bg-ivory-dark border border-navy/30 hover:bg-gold hover:text-white'
              }`}
            >
              {isBookmarked ? '★' : '☆'}
            </button>
          </div>
        </div>

        <div className="mt-4 md:mt-0 md:ml-auto">
          <div className="flex items-center gap-2">
            <span className="text-[0.7rem] font-semibold text-navy uppercase tracking-widest">Chapter</span>
            <select
              value={chapterIdx}
              onChange={(e) => onChapterChange(Number(e.target.value))}
              className="bg-white border border-navy/30 text-navy text-sm rounded px-3 py-1.5 focus:outline-none focus:border-gold"
            >
              {chapters.map((c, i) => (
                <option key={c.id} value={i}>{c.title}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
        )}
        {open && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="fixed inset-x-0 bottom-16 z-50 w-full max-w-md mx-auto bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="bg-navy p-4 flex items-center justify-between">
              <h3 className="text-base font-serif font-bold text-white">Table of contents</h3>
              <button
                onClick={() => setOpen(false)}
                className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
              >
                <X />
              </button>
            </div>
            <div className="max-h-[60vh] overflow-y-auto pr-2">
              {chapters.map((c, ci) => (
                <div key={c.id} className="border-b border-navy/5 last:border-0">
                  <button
                    onClick={() => { onChapterChange(ci); setOpen(false); }}
                    className={`w-full flex justify-between items-center px-6 py-3 text-left transition ${ci === chapterIdx ? 'bg-gold/10 text-navy font-semibold' : 'text-ink/70 hover:bg-ivory-dark'}`}
                  >
                    <span className="font-serif">{c.title}</span>
                    <span className="text-[0.65rem] text-ink/40 font-mono">{c.spreads.length} spreads</span>
                  </button>
                  <div className="flex gap-1 px-6 pb-2">
                    {c.spreads.map((s, si) => (
                      <button
                        key={s.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onGoToSpread(s.id);
                          setOpen(false);
                        }}
                        className={`w-6 h-6 rounded-full text-[0.6rem] flex items-center justify-center transition ${
                          ci === chapterIdx && si === spreadIdx
                            ? 'bg-navy text-white'
                            : bookmarks.has(s.id)
                              ? 'bg-gold text-white'
                              : 'border border-navy/30 text-ink/60 hover:bg-gold hover:text-white'
                        }`}
                        title={s.title}
                      >
                        {si + 1}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
            onClick={() => setSearchOpen(false)}
          />
        )}
        {searchOpen && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="fixed inset-x-0 bottom-16 z-50 w-full max-w-md mx-auto bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="bg-navy p-4 flex items-center justify-between">
              <h3 className="text-base font-serif font-bold text-white">Search</h3>
              <button
                onClick={() => setSearchOpen(false)}
                className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
              >
                <X />
              </button>
            </div>
            <div className="p-4">
              <input
                ref={inputRef}
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search lecture content..."
                className="w-full p-3 pl-10 rounded-lg border border-navy/30 bg-white text-sm font-serif focus:outline-none focus:border-gold"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy/50" />
            </div>
            {searchResults.length > 0 ? (
              <div className="max-h-[40vh] overflow-y-auto pr-2">
                {searchResults.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => { onGoToSpread(s.id); setSearchOpen(false); }}
                    className="w-full px-6 py-3 text-left border-b border-navy/5 hover:bg-gold/5 transition"
                  >
                    <div className="text-sm font-serif font-semibold text-navy">{s.title}</div>
                    <div className="text-[0.7rem] text-ink/50 mt-0.5">
                      Chapter {chapters.findIndex((c) => c.id === s.chapterId) + 1} • Spread {s.spreadIndex + 1}
                    </div>
                  </button>
                ))}
              </div>
            ) : searchQuery.trim() ? (
              <div className="p-6 text-center text-sm text-ink/50">No results found</div>
            ) : null}
            <div className="pt-4 pb-6 border-t border-navy/10 flex justify-end">
              <button
                onClick={() => { setSearchQuery(''); onCloseSearch(); }}
                className="text-sm text-navy hover:text-teal"
              >
                Clear
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
