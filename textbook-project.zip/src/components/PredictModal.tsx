import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Play, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';
import type { PredictFeature } from '@/types';

interface PredictModalProps {
  feature: PredictFeature;
  onComplete: () => void;
  onRunDiagram: () => void;
}

export default function PredictModal({ feature, onComplete, onRunDiagram }: PredictModalProps) {
  const [stage, setStage] = useState<'question' | 'reveal'>('question');
  const [selected, setSelected] = useState<string | null>(null);
  const [ran, setRan] = useState(false);

  const isCorrect = selected === feature.correctId;

  const handleSelect = (id: string) => {
    setSelected(id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 pointer-events-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="pointer-events-auto relative w-full max-w-lg bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
      >
        <div className="bg-navy p-5 flex items-center justify-between">
          <h2 className="text-lg font-serif font-bold text-white">
            Predict before reveal
          </h2>
          <button
            onClick={onComplete}
            className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
          >
            <X />
          </button>
        </div>

        <div className="p-6 md:p-8">
          <div className="text-ink/80 leading-relaxed mb-6 text-sm md:text-base font-serif">
            {feature.question}
          </div>

          {stage === 'question' ? (
            <div className="space-y-3">
              {feature.options.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => handleSelect(opt.id)}
                  disabled={selected !== null}
                  className={`w-full text-left py-3 px-4 rounded-lg border text-sm font-serif text-left transition-all ${
                    selected === null
                      ? 'border-navy/30 text-ink hover:bg-ivory-dark'
                      : selected === opt.id
                        ? isCorrect
                          ? 'border-gold bg-gold/10 text-navy'
                          : 'border-red/30 bg-red/5 text-red/90'
                        : 'border-navy/20 text-ink/60 bg-ivory/50'
                  }`}
                >
                  {opt.text}
                </button>
              ))}
              {selected !== null && (
                <div className="mt-4">
                  <button
                    onClick={onRunDiagram}
                    disabled={!ran}
                    className="w-full py-3 px-4 bg-navy text-white rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-teal transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Play className="w-5 h-5" />
                    {ran ? 'Animation ready' : 'Run scientific animation'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <div className="flex items-start gap-3 mb-6">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${
                  isCorrect ? 'bg-green/10 text-green-800 border border-green/30' : 'bg-red/10 text-red-800 border border-red/30'
                }`}>
                  {isCorrect ? '✓' : '✗'}
                </div>
                <div className="text-sm text-ink leading-relaxed font-serif">
                  {isCorrect
                    ? `Correct — ${feature.explanation}`
                    : `Not quite. ${feature.explanation}`}
                </div>
              </div>
              <div className="space-y-4">
                {feature.options.map((opt) => {
                  const correct = opt.id === feature.correctId;
                  const chosen = opt.id === selected;
                  if (!correct && !chosen) return null;
                  return (
                    <div key={opt.id} className="p-3 rounded-lg text-sm font-serif leading-relaxed">
                      {correct ? (
                        <div className="flex items-start gap-2">
                          <span className="mt-0.5 text-green-800 font-bold">✓ Correct:</span>{' '}
                          {feature.explanation}
                        </div>
                      ) : (
                        <div className="flex items-start gap-2">
                          <span className="mt-0.5 text-red-800 font-bold">✗ Your choice:</span>{' '}
                          {opt.text}
                          <br />
                          <span className="text-red-800/80 mt-1 block text-xs">
                            Why incorrect: {feature.incorrectExplanations[opt.id]}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="mt-6 pt-6 border-t border-navy/10 flex items-center justify-between">
                <button
                  onClick={() => {
                    setStage('question');
                    setSelected(null);
                    setRan(false);
                  }}
                  className="text-sm text-navy hover:text-teal flex items-center gap-1"
                >
                  <RefreshCw className="w-4 h-4" /> Try another prediction
                </button>
                <button
                  onClick={onComplete}
                  className="text-sm font-semibold text-navy hover:text-teal"
                >
                  Close
                </button>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
