import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import type { HotspotDef } from '@/types';

interface HotspotPanelProps {
  hotspots: HotspotDef[];
  activeId: string;
  onClose: () => void;
}

export default function HotspotPanel({ hotspots, activeId, onClose }: HotspotPanelProps) {
  const hs = hotspots.find((h) => h.id === activeId);
  if (!hs) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 pointer-events-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="pointer-events-auto relative w-full max-w-lg bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
      >
        <div className="bg-navy p-5 flex items-center justify-between">
          <h2 className="text-lg font-serif font-bold text-white">Component detail</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
          >
            <X />
          </button>
        </div>

        <div className="p-6 md:p-8">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded bg-navy flex items-center justify-center text-white text-lg font-bold shadow shrink-0">
              {hs.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-navy mb-1">{hs.name}</h3>
              <p className="text-sm text-teal font-medium">Position: ({hs.position.join(', ')})</p>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <h4 className="text-xs font-semibold text-navy uppercase tracking-wider mb-2">Function</h4>
              <p className="text-sm text-ink/85 font-serif leading-relaxed">{hs.function}</p>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-navy uppercase tracking-wider mb-2">Importance</h4>
              <p className="text-sm text-ink/85 font-serif leading-relaxed">{hs.importance}</p>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-navy uppercase tracking-wider mb-2">Relationship</h4>
              <p className="text-sm text-ink/85 font-serif leading-relaxed">{hs.relationship}</p>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-navy/10 flex justify-end">
            <button onClick={onClose} className="text-sm font-semibold text-navy hover:text-teal">
              Close
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
