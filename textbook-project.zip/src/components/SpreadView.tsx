import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen } from 'lucide-react';
import { CHAPTERS } from '@/content/data';
import type { Spread, Chapter } from '@/types';
import ContentRenderer from './ContentRenderer';

interface SpreadViewProps {
  spread: Spread;
  chapter: Chapter;
  chapterIdx: number;
  spreadIdx: number;
  onDiagramSelect: (kind: string) => void;
  onHotspotSelect: (id: string) => void;
  onPrev: () => void;
  onNext: () => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
}

export default function SpreadView({
  spread,
  chapter,
  chapterIdx,
  spreadIdx,
  onDiagramSelect,
  onHotspotSelect,
  onPrev,
  onNext,
  isBookmarked,
  onToggleBookmark,
}: SpreadViewProps) {
  const hasDiagram = !!spread.diagram;
  const hasPredict = !!spread.features?.predictBeforeReveal;
  const hasFlap = !!spread.features?.liftTheFlap;
  const hasSteps = !!spread.features?.stepAnimation;
  const hasQuiz = !!spread.features?.knowledgeCheck;
  const hasHotspots = !!(spread.features?.hotspots && spread.features.hotspots.length);

  const isFirst = chapterIdx === 0 && spreadIdx === 0;
  const isLast =
    chapterIdx === CHAPTERS.length - 1 && spreadIdx === chapter.spreads.length - 1;

  return (
    <div className="spread-overlay fixed inset-0 z-20 pointer-events-none flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.98 }}
        transition={{ type: 'spring', damping: 22, stiffness: 300 }}
        className="pointer-events-auto relative w-full max-w-[1180px] h-[700px] md:h-[820px] rounded-xl bg-white/60 backdrop-filter backdrop-blur-sm border border-navy/10 shadow-2xl overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #f9f7f1 0%, #f1ead4 60%, #efe9d9 100%)' }}
      >
        <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-[10px] bg-gradient-to-r from-black/12 via-transparent to-transparent pointer-events-none" />

        <div className="flex h-full">
          {/* ================= LEFT PAGE ================= */}
          <div className="flex-1 h-full p-8 md:p-12 overflow-y-auto border-r border-navy/20 relative">
            <div className="flex items-start justify-between mb-2">
              <div className="flex -space-x-2">
                <div className="w-6 h-6 rounded-full bg-navy flex items-center justify-center text-white text-xs font-bold shadow">L</div>
                <div className="w-6 h-6 rounded-full bg-ivory-dark border border-navy/40 flex items-center justify-center text-navy text-xs font-bold shadow ml-1">EFT</div>
              </div>
              <div className="ml-auto">
                <button
                  onClick={onToggleBookmark}
                  className={`w-8 h-8 rounded flex items-center justify-center text-navy transition all ${
                    isBookmarked ? 'bg-gold text-white' : 'bg-ivory-dark border border-navy/30 hover:bg-gold hover:text-white'
                  }`}
                  title={isBookmarked ? 'Remove bookmark' : 'Bookmark'}
                >
                  {isBookmarked ? '★' : '☆'}
                </button>
              </div>
            </div>

            <h1 className="text-3xl md:text-4xl font-serif font-bold text-navy mb-1 tracking-tight leading-tight">
              {spread.title}
            </h1>
            <p className="text-teal text-sm font-medium mb-6 md:mb-8 uppercase tracking-wider">
              {chapter.subtitle}
            </p>

            {chapter.learningObjectives && chapter.learningObjectives.length > 0 && (
              <div className="mb-6 md:mb-8">
                <h3 className="text-xs font-semibold text-navy uppercase tracking-widest mb-3 border-b border-navy/20 pb-1">
                  Learning objectives
                </h3>
                <ul className="space-y-1.5 text-sm text-ink/85 leading-relaxed">
                  {chapter.learningObjectives.map((obj, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="mt-0.5 w-1.5 h-1.5 rounded-full bg-gold shrink-0"></span>
                      {obj}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mb-6 md:mb-8">
              <h3 className="text-xs font-semibold text-navy uppercase tracking-widest mb-3 border-b border-navy/20 pb-1">
                Lesson content
              </h3>
              <ContentRenderer blocks={spread.left} className="left-page-content" />
            </div>

            {spread.estimatedMinutes && (
              <div className="mt-6 md:mt-8 pt-4 border-t border-navy/10 flex items-center gap-3 text-xs text-ink/60">
                <span className="w-2 h-2 rounded-full bg-sage"></span>
                <span>Estimated study time: {spread.estimatedMinutes} min</span>
              </div>
            )}

            <div className="mt-auto pt-6 md:pt-10 border-t border-gold/30">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-5 h-5 rounded bg-gold/20 flex items-center justify-center text-gold text-xs font-bold">DN</div>
                <h3 className="text-sm font-semibold text-navy uppercase tracking-wider">Doctor's notes</h3>
              </div>
              <p className="text-sm text-ink/70 italic leading-relaxed border-l-2 border-gold pl-3">
                Record key observations as you study. Clinical relevance: apply the principles on this
                spread when evaluating liquid formulations in practice.
              </p>
            </div>
          </div>

          {/* ================= RIGHT PAGE ================= */}
          <div className="flex-1 h-full p-8 md:p-12 overflow-y-auto relative">
            <div className="flex -space-x-2">
              <div className="w-6 h-6 rounded-full bg-ivory-dark border border-navy/40 flex items-center justify-center text-navy text-xs font-bold shadow ml-1">RI</div>
              <div className="w-6 h-6 rounded-full bg-navy flex items-center justify-center text-white text-xs font-bold shadow">GHT</div>
            </div>

            <h2 className="text-xl md:text-2xl font-serif font-bold text-navy mb-1 md:mb-4 tracking-tight">
              Visual explanation
            </h2>

            <div className="mb-6">
              <ContentRenderer blocks={spread.right} className="right-page-content" />
            </div>

            {hasDiagram && (
              <div className="mt-6 md:mt-8">
                <button
                  onClick={() => onDiagramSelect(spread.diagram!.kind)}
                  className="w-full md:w-auto py-4 md:py-5 px-6 bg-navy text-white rounded-lg font-serif font-semibold text-lg hover:bg-teal transition-all shadow-lg hover:shadow-xl hover:-translate-y-1 flex items-center justify-center gap-2 group"
                >
                  <BookOpen className="w-6 h-6" />
                  Explore 3D diagram — {spread.diagram!.title}
                  <span className="group-hover:rotate-180 transition-transform duration-300">▸</span>
                </button>
                <p className="text-[0.75rem] text-ink/50 mt-2 text-center md:text-left max-w-md mx-auto md:mx-0">
                  Interactive model emerges from the right page. Rotate • Zoom • Inspect components
                </p>
              </div>
            )}

            {hasHotspots && (
              <div className="mt-6 md:mt-8">
                <h3 className="text-xs font-semibold text-navy uppercase tracking-widest mb-3">
                  Interactive hotspots
                </h3>
                <p className="text-sm text-ink/70 mb-3">
                  Select a component of the 3D diagram to reveal its name, function, and importance.
                </p>
                <div className="flex gap-3">
                  {(spread.features!.hotspots as any[]).slice(0, 4).map((hs) => (
                    <button
                      key={hs.id}
                      onClick={() => onHotspotSelect(hs.id)}
                      className="flex-1 min-w-[140px] py-3 px-3 bg-ivory-dark border border-navy/20 rounded text-xs text-navy font-medium hover:bg-gold hover:text-white transition-all leading-tight"
                    >
                      {hs.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-auto pt-6 md:pt-10 grid grid-cols-1 md:grid-cols-2 gap-4">
              {hasPredict && (
                <button
                  onClick={() => {}}
                  className="group bg-ivory-dark border border-navy/30 rounded-xl p-4 hover:bg-gold hover:text-white transition-all"
                >
                  <div className="flex items-center gap-2 text-navy group-hover:text-white">
                    <span className="font-medium">Predict before reveal</span>
                  </div>
                  <div className="text-[0.75rem] text-ink/60 mt-1 group-hover:text-white/90">
                    Anticipate the mechanism, then watch the animation
                  </div>
                </button>
              )}
              {hasFlap && (
                <button
                  onClick={() => {}}
                  className="group bg-ivory-dark border border-navy/30 rounded-xl p-4 hover:bg-gold hover:text-white transition-all"
                >
                  <div className="flex items-center gap-2 text-navy group-hover:text-white">
                    <span className="font-medium">Lift-the-flap answer</span>
                  </div>
                  <div className="text-[0.75rem] text-ink/60 mt-1 group-hover:text-white/90">
                    Answer before opening the hidden flap
                  </div>
                </button>
              )}
              {hasSteps && (
                <button
                  onClick={() => {}}
                  className="group bg-ivory-dark border border-navy/30 rounded-xl p-4 hover:bg-gold hover:text-white transition-all"
                >
                  <div className="flex items-center gap-2 text-navy group-hover:text-white">
                    <span className="font-medium">Step-by-step animation</span>
                  </div>
                  <div className="text-[0.75rem] text-ink/60 mt-1 group-hover:text-white/90">
                    Mechanism broken into sequential steps
                  </div>
                </button>
              )}
              {hasQuiz && (
                <button
                  onClick={() => {}}
                  className="group bg-ivory-dark border border-navy/30 rounded-xl p-4 hover:bg-gold hover:text-white transition-all"
                >
                  <div className="flex items-center gap-2 text-navy group-hover:text-white">
                    <span className="font-medium">Knowledge check</span>
                  </div>
                  <div className="text-[0.75rem] text-ink/60 mt-1 group-hover:text-white/90">
                    End-of-lesson self-assessment
                  </div>
                </button>
              )}
          </div>
        </div>
        </div>

        <div className="absolute inset-y-0 flex justify-between items-center w-full px-6 md:px-10 pointer-events-none">
          <button
            onClick={onPrev}
            disabled={isFirst}
            className="pointer-events-auto w-12 h-12 rounded-full bg-ivory-dark/90 backdrop-blur border border-navy/30 text-navy flex items-center justify-center text-xl font-bold shadow-xl hover:bg-gold hover:text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            ◀
          </button>
          <button
            onClick={onNext}
            disabled={isLast}
            className="pointer-events-auto w-12 h-12 rounded-full bg-ivory-dark/90 backdrop-blur border border-navy/30 text-navy flex items-center justify-center text-xl font-bold shadow-xl hover:bg-gold hover:text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            ▶
          </button>
        </div>
      </motion.div>
    </div>
  );
}
