import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, ChevronDown } from 'lucide-react';
import type { LiftTheFlapFeature } from '@/types';

interface LiftTheFlapProps {
  feature: LiftTheFlapFeature;
  onClose: () => void;
}

export default function LiftTheFlap({ feature, onClose }: LiftTheFlapProps) {
  const [opened, setOpened] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 pointer-events-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="pointer-events-auto relative w-full max-w-lg bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
      >
        <div className="bg-navy p-5 flex items-center justify-between">
          <h2 className="text-lg font-serif font-bold text-white">Lift-the-flap answer</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
          >
            <X />
          </button>
        </div>

        <div className="p-6 md:p-8">
          <div className="text-ink/80 leading-relaxed mb-6 text-sm md:text-base font-serif">
            {feature.question}
          </div>

          {/* The flap */}
          <motion.div
            className="relative rounded-xl border border-navy/30 bg-ivory-dark overflow-hidden shadow-lg"
            style={{ height: opened ? 260 : 110 }}
            animate={{ height: opened ? 260 : 110 }}
            transition={{ type: 'spring', damping: 20, stiffness: 250 }}
          >
            {/* Flap header (the part that "folds" open) */}
            <motion.div
              className="bg-navy/90 p-5 cursor-pointer select-none"
              onClick={() => setOpened(!opened)}
              onKeyDown={(e) => e.key === 'Enter' && setOpened(!opened)}
              tabIndex={0}
              role="button"
              aria-pressed={opened}
              aria-label={opened ? 'Close flap' : 'Open flap'}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-serif font-bold text-white">Answer</span>
                  <ChevronDown className={`w-4 h-4 text-gold transition-transform ${opened ? 'rotate-180' : ''}`} />
                </div>
                <span className="text-xs text-gold/80 font-mono">
                  {opened ? 'Open — click to close' : 'Closed — click to open'}
                </span>
              </div>
              {!opened && (
                <p className="text-navy/60 text-sm mt-2 font-serif">
                  Think about your answer, then open the flap to check.
                </p>
              )}
            </motion.div>

            {opened && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 border-t border-navy/10 bg-white"
              >
                <div className="flex items-start gap-2 mb-3">
                  <span className="w-6 h-6 rounded bg-green/10 text-green-800 flex items-center justify-center text-xs font-bold shrink-0">
                    ✓
                  </span>
                  <div>
                    <div className="font-serif font-bold text-navy text-sm">Correct concept</div>
                    <div className="text-[0.85rem] text-ink/80 leading-relaxed">{feature.answer}</div>
                  </div>
                </div>
                <div className="border-l-2 border-gold bg-gold/5 p-3 mt-3">
                  <div className="text-xs font-semibold text-navy uppercase tracking-wider mb-1">Explanation</div>
                  <p className="text-sm text-ink/80 leading-relaxed font-serif">{feature.explanation}</p>
                </div>
              </motion.div>
            )}
          </motion.div>

          <div className="mt-6 flex justify-end">
            <button onClick={onClose} className="text-sm font-semibold text-navy hover:text-teal">
              Close
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
