import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { X, Play, Pause, SkipForward, SkipBack, RefreshCw } from 'lucide-react';
import type { StepAnimationDef } from '@/types';

interface StepPlayerProps {
  steps: { label: string; description: string }[];
  title: string;
  onClose: () => void;
}

export default function StepPlayer({ steps, title, onClose }: StepPlayerProps) {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const timer = useRef<number | null>(null);

  const advance = useCallback(() => {
    setIndex((i) => (i >= steps.length - 1 ? 0 : i + 1));
  }, [steps.length]);

  const goBack = useCallback(() => {
    setIndex((i) => (i <= 0 ? steps.length - 1 : i - 1));
  }, [steps.length]);

  useEffect(() => {
    if (!playing) return;
    timer.current = window.setInterval(advance, 2200);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [playing, advance]);

  const togglePlay = useCallback(() => setPlaying((p) => !p), []);
  const replay = useCallback(() => {
    setIndex(0);
    setPlaying(false);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 pointer-events-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="pointer-events-auto relative w-full max-w-lg bg-white rounded-2xl border border-navy/20 shadow-2xl overflow-hidden flex flex-col"
      >
        <div className="bg-navy p-5 flex items-center justify-between">
          <h2 className="text-lg font-serif font-bold text-white">{title}</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded bg-white/10 text-white flex items-center justify-center hover:bg-white/20"
          >
            <X />
          </button>
        </div>

        <div className="p-6 md:p-8 flex flex-col h-[520px]">
          {/* Controls */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-navy uppercase tracking-wider">
                Step {index + 1} of {steps.length}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={goBack}
                className="w-9 h-9 rounded bg-ivory-dark text-navy flex items-center justify-center hover:bg-gold hover:text-white transition"
                disabled={!playing && index === 0}
              >
                <SkipBack className="w-5 h-5" />
              </button>
              <button
                onClick={togglePlay}
                className="w-9 h-9 rounded bg-navy text-white flex items-center justify-center hover:bg-teal transition"
              >
                {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <button
                onClick={replay}
                className="w-9 h-9 rounded bg-ivory-dark text-navy flex items-center justify-center hover:bg-gold hover:text-white transition"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
              <button
                onClick={advance}
                className="w-9 h-9 rounded bg-ivory-dark text-navy flex items-center justify-center hover:bg-gold hover:text-white transition"
                disabled={!playing && index === steps.length - 1}
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Active step */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            key={index}
            className="flex-1 bg-ivory-dark rounded-2xl p-6 md:p-10 border border-navy/20 shadow-inner flex flex-col items-center justify-center text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gold/10 opacity-0 pointer-events-none" />
            <div className="relative z-10">
              <div className="w-10 h-10 rounded-full bg-navy flex items-center justify-center text-white text-lg font-bold mb-4 shadow-lg">
                {index + 1}
              </div>
              <h3 className="text-lg md:text-xl font-serif font-bold text-navy mb-3">
                {steps[index].label}
              </h3>
              <p className="text-sm md:text-base text-ink/85 leading-relaxed font-serif max-w-md">
                {steps[index].description}
              </p>
            </div>
          </motion.div>

          <div className="mt-4 flex items-center justify-between text-xs text-ink/50">
            <span>
              {playing ? 'Auto-advancing every 2.2s' : 'Use Next / Previous or Play'}
            </span>
            <button
              onClick={onClose}
              className="font-semibold text-navy hover:text-teal"
            >
              Close
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
